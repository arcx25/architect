# ARCHITECT Market Deployment Guide

## Quick Deploy (Manual)

1. Download ZIP from v0 (three dots menu → Download ZIP)

2. Extract and transfer to server:
   ```bash
   unzip architect.zip
   scp -r architect/* root@38.54.24.253:/tmp/architect/
   ```

3. SSH and run deployment:
   ```bash
   ssh root@38.54.24.253
   cd /tmp/architect
   chmod +x deploy.sh
   ./deploy.sh -v 2>&1 | tee deploy.log
   ```

4. Get your onion address:
   ```bash
   cat /var/lib/tor/architect/hostname
   ```

## GitHub Actions Deploy

1. Add these secrets to your GitHub repository:
   - `DEPLOY_HOST`: Your server IP (38.54.24.253)
   - `DEPLOY_USER`: SSH username (root)
   - `DEPLOY_SSH_KEY`: Your SSH private key

2. Trigger deployment:
   - Go to Actions → Deploy ARCHITECT Market → Run workflow

## What the Deploy Script Does

1. Validates server (OS, memory, disk)
2. Installs system packages (Python, PostgreSQL, Redis, Tor, GnuPG)
3. Creates application directories with proper permissions
4. Sets up Python virtual environment
5. Installs Python dependencies from requirements.txt
6. Configures PostgreSQL database
7. Runs database migrations (001_init_schema.sql)
8. Generates 4096-bit RSA server PGP keypair
9. Configures Tor hidden service
10. Creates systemd service with security hardening
11. Starts application and verifies health

## Monitoring

```bash
# View application logs
journalctl -u architect -f

# Check service status  
systemctl status architect

# View deployment log
cat /var/log/architect-deploy-*.log
```

## Security Notes

- Server PGP key stored in /var/lib/architect/gnupg (mode 700)
- Application runs as www-data user
- Database credentials auto-generated during deployment
- Tor hidden service configured automatically
- Zero JavaScript - all server-rendered HTML
