-- ARCHITECT Market Database Schema
-- Version: 1.0.0
-- Zero JavaScript | PGP-Only Auth | Monero Payments

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ============================================
-- ENUM TYPES
-- ============================================

CREATE TYPE account_tier AS ENUM ('buyer', 'vendor', 'admin');
CREATE TYPE order_status AS ENUM (
    'pending_payment',
    'paid',
    'processing',
    'shipped',
    'delivered',
    'disputed',
    'completed',
    'cancelled',
    'refunded',
    'auto_finalized'
);
CREATE TYPE deposit_status AS ENUM ('pending', 'confirming', 'confirmed', 'expired');
CREATE TYPE escrow_status AS ENUM ('held', 'released_vendor', 'refunded_buyer', 'split');
CREATE TYPE dispute_status AS ENUM (
    'open',
    'vendor_response',
    'buyer_response',
    'admin_review',
    'resolved_buyer',
    'resolved_vendor',
    'resolved_split'
);

-- ============================================
-- USERS TABLE
-- ============================================

CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    username VARCHAR(20) UNIQUE NOT NULL,
    pgp_fingerprint VARCHAR(64) UNIQUE NOT NULL,
    pgp_public_key TEXT NOT NULL,
    account_tier account_tier DEFAULT 'buyer',
    balance_xmr DECIMAL(16, 12) DEFAULT 0,
    escrow_balance_xmr DECIMAL(16, 12) DEFAULT 0,
    anti_phishing_phrase VARCHAR(100),
    canary_active BOOLEAN DEFAULT TRUE,
    total_sales INTEGER DEFAULT 0,
    total_purchases INTEGER DEFAULT 0,
    rating DECIMAL(3, 2) DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    last_login TIMESTAMP WITH TIME ZONE,
    upgraded_at TIMESTAMP WITH TIME ZONE,
    
    CONSTRAINT username_format CHECK (username ~ '^[a-z0-9_]{3,20}$'),
    CONSTRAINT rating_range CHECK (rating >= 0 AND rating <= 5)
);

CREATE INDEX idx_users_username ON users(username);
CREATE INDEX idx_users_pgp_fingerprint ON users(pgp_fingerprint);
CREATE INDEX idx_users_account_tier ON users(account_tier);

-- ============================================
-- SESSIONS TABLE
-- ============================================

CREATE TABLE sessions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token VARCHAR(64) UNIQUE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    ip_hash VARCHAR(64),
    user_agent_hash VARCHAR(64)
);

CREATE INDEX idx_sessions_token ON sessions(token);
CREATE INDEX idx_sessions_user_id ON sessions(user_id);
CREATE INDEX idx_sessions_expires_at ON sessions(expires_at);

-- ============================================
-- PGP CHALLENGES TABLE
-- ============================================

CREATE TABLE pgp_challenges (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    username VARCHAR(20) NOT NULL,
    challenge_hash VARCHAR(64) NOT NULL,
    pgp_fingerprint VARCHAR(64),
    pgp_public_key TEXT,
    purpose VARCHAR(20) NOT NULL, -- 'register' or 'login'
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    used BOOLEAN DEFAULT FALSE
);

CREATE INDEX idx_pgp_challenges_username ON pgp_challenges(username);
CREATE INDEX idx_pgp_challenges_expires_at ON pgp_challenges(expires_at);

-- ============================================
-- PRODUCTS TABLE
-- ============================================

CREATE TABLE products (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    vendor_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title VARCHAR(200) NOT NULL,
    description TEXT NOT NULL,
    price_xmr DECIMAL(16, 12) NOT NULL,
    category VARCHAR(50) NOT NULL,
    stock INTEGER DEFAULT 0,
    rating DECIMAL(3, 2) DEFAULT 0,
    total_sales INTEGER DEFAULT 0,
    shipping_options JSONB DEFAULT '["Digital Delivery"]',
    images JSONB DEFAULT '[]',
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    CONSTRAINT positive_price CHECK (price_xmr > 0),
    CONSTRAINT non_negative_stock CHECK (stock >= 0)
);

CREATE INDEX idx_products_vendor_id ON products(vendor_id);
CREATE INDEX idx_products_category ON products(category);
CREATE INDEX idx_products_is_active ON products(is_active);
CREATE INDEX idx_products_created_at ON products(created_at DESC);

-- ============================================
-- ORDERS TABLE
-- ============================================

CREATE TABLE orders (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    buyer_id UUID NOT NULL REFERENCES users(id),
    vendor_id UUID NOT NULL REFERENCES users(id),
    product_id UUID NOT NULL REFERENCES products(id),
    quantity INTEGER NOT NULL DEFAULT 1,
    price_xmr DECIMAL(16, 12) NOT NULL,
    total_xmr DECIMAL(16, 12) NOT NULL,
    fee_xmr DECIMAL(16, 12) NOT NULL,
    status order_status DEFAULT 'pending_payment',
    shipping_address_encrypted TEXT NOT NULL,
    shipping_option VARCHAR(50) NOT NULL,
    tracking_encrypted TEXT,
    notes_encrypted TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    paid_at TIMESTAMP WITH TIME ZONE,
    shipped_at TIMESTAMP WITH TIME ZONE,
    delivered_at TIMESTAMP WITH TIME ZONE,
    completed_at TIMESTAMP WITH TIME ZONE,
    autofinalize_at TIMESTAMP WITH TIME ZONE,
    
    CONSTRAINT positive_quantity CHECK (quantity > 0),
    CONSTRAINT buyer_not_vendor CHECK (buyer_id != vendor_id)
);

CREATE INDEX idx_orders_buyer_id ON orders(buyer_id);
CREATE INDEX idx_orders_vendor_id ON orders(vendor_id);
CREATE INDEX idx_orders_status ON orders(status);
CREATE INDEX idx_orders_created_at ON orders(created_at DESC);
CREATE INDEX idx_orders_autofinalize_at ON orders(autofinalize_at) WHERE status = 'shipped';

-- ============================================
-- ESCROWS TABLE
-- ============================================

CREATE TABLE escrows (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    order_id UUID UNIQUE NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    buyer_id UUID NOT NULL REFERENCES users(id),
    vendor_id UUID NOT NULL REFERENCES users(id),
    amount_xmr DECIMAL(16, 12) NOT NULL,
    fee_xmr DECIMAL(16, 12) NOT NULL,
    status escrow_status DEFAULT 'held',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    released_at TIMESTAMP WITH TIME ZONE
);

CREATE INDEX idx_escrows_order_id ON escrows(order_id);
CREATE INDEX idx_escrows_status ON escrows(status);

-- ============================================
-- DISPUTES TABLE
-- ============================================

CREATE TABLE disputes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    order_id UUID UNIQUE NOT NULL REFERENCES orders(id),
    buyer_id UUID NOT NULL REFERENCES users(id),
    vendor_id UUID NOT NULL REFERENCES users(id),
    reason TEXT NOT NULL,
    buyer_evidence TEXT,
    vendor_response TEXT,
    admin_notes TEXT,
    status dispute_status DEFAULT 'open',
    resolution_amount_buyer DECIMAL(16, 12) DEFAULT 0,
    resolution_amount_vendor DECIMAL(16, 12) DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    resolved_at TIMESTAMP WITH TIME ZONE,
    resolved_by UUID REFERENCES users(id)
);

CREATE INDEX idx_disputes_order_id ON disputes(order_id);
CREATE INDEX idx_disputes_status ON disputes(status);

-- ============================================
-- DEPOSITS TABLE
-- ============================================

CREATE TABLE deposits (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id),
    address VARCHAR(106) NOT NULL,
    payment_id VARCHAR(16) NOT NULL,
    expected_amount DECIMAL(16, 12) DEFAULT 0,
    received_amount DECIMAL(16, 12) DEFAULT 0,
    purpose VARCHAR(20) NOT NULL, -- 'wallet', 'order', 'vendor_upgrade'
    reference_id UUID, -- Order ID or other reference
    status deposit_status DEFAULT 'pending',
    tx_hash VARCHAR(64),
    confirmations INTEGER DEFAULT 0,
    signed_details TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    confirmed_at TIMESTAMP WITH TIME ZONE
);

CREATE INDEX idx_deposits_user_id ON deposits(user_id);
CREATE INDEX idx_deposits_address ON deposits(address);
CREATE INDEX idx_deposits_status ON deposits(status);
CREATE INDEX idx_deposits_expires_at ON deposits(expires_at) WHERE status = 'pending';

-- ============================================
-- MESSAGES TABLE
-- ============================================

CREATE TABLE messages (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    sender_id UUID NOT NULL REFERENCES users(id),
    recipient_id UUID NOT NULL REFERENCES users(id),
    subject VARCHAR(200) NOT NULL,
    content_encrypted TEXT NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    CONSTRAINT sender_not_recipient CHECK (sender_id != recipient_id)
);

CREATE INDEX idx_messages_sender_id ON messages(sender_id);
CREATE INDEX idx_messages_recipient_id ON messages(recipient_id);
CREATE INDEX idx_messages_is_read ON messages(is_read) WHERE is_read = FALSE;
CREATE INDEX idx_messages_created_at ON messages(created_at DESC);

-- ============================================
-- VENDOR APPLICATIONS TABLE
-- ============================================

CREATE TABLE vendor_applications (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID UNIQUE NOT NULL REFERENCES users(id),
    deposit_id UUID REFERENCES deposits(id),
    description TEXT,
    status VARCHAR(20) DEFAULT 'pending_payment',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    approved_at TIMESTAMP WITH TIME ZONE
);

CREATE INDEX idx_vendor_applications_user_id ON vendor_applications(user_id);
CREATE INDEX idx_vendor_applications_status ON vendor_applications(status);

-- ============================================
-- POW CHALLENGES TABLE
-- ============================================

CREATE TABLE pow_challenges (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    answer INTEGER NOT NULL,
    instruction TEXT NOT NULL,
    numbers JSONB NOT NULL,
    circuit_hash VARCHAR(64),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    used BOOLEAN DEFAULT FALSE
);

CREATE INDEX idx_pow_challenges_expires_at ON pow_challenges(expires_at);

-- ============================================
-- POW BYPASS TOKENS TABLE
-- ============================================

CREATE TABLE pow_bypass_tokens (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    token VARCHAR(64) UNIQUE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL
);

CREATE INDEX idx_pow_bypass_tokens_token ON pow_bypass_tokens(token);
CREATE INDEX idx_pow_bypass_tokens_expires_at ON pow_bypass_tokens(expires_at);

-- ============================================
-- AUDIT LOG TABLE
-- ============================================

CREATE TABLE audit_log (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id),
    action VARCHAR(50) NOT NULL,
    entity_type VARCHAR(50),
    entity_id UUID,
    details JSONB,
    ip_hash VARCHAR(64),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_audit_log_user_id ON audit_log(user_id);
CREATE INDEX idx_audit_log_action ON audit_log(action);
CREATE INDEX idx_audit_log_created_at ON audit_log(created_at DESC);

-- ============================================
-- SERVER KEY TABLE
-- ============================================

CREATE TABLE server_keys (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    key_id VARCHAR(40) NOT NULL,
    fingerprint VARCHAR(64) UNIQUE NOT NULL,
    public_key TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    expires_at TIMESTAMP WITH TIME ZONE,
    is_active BOOLEAN DEFAULT TRUE
);

-- ============================================
-- CANARY TABLE
-- ============================================

CREATE TABLE canary (
    id SERIAL PRIMARY KEY,
    message TEXT NOT NULL,
    signed_message TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ============================================
-- FUNCTIONS AND TRIGGERS
-- ============================================

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Trigger for products
CREATE TRIGGER update_products_updated_at
    BEFORE UPDATE ON products
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- Function to cleanup expired sessions
CREATE OR REPLACE FUNCTION cleanup_expired_sessions()
RETURNS void AS $$
BEGIN
    DELETE FROM sessions WHERE expires_at < NOW();
    DELETE FROM pgp_challenges WHERE expires_at < NOW();
    DELETE FROM pow_challenges WHERE expires_at < NOW();
    DELETE FROM pow_bypass_tokens WHERE expires_at < NOW();
END;
$$ LANGUAGE plpgsql;

-- Function to expire pending deposits
CREATE OR REPLACE FUNCTION expire_pending_deposits()
RETURNS void AS $$
BEGIN
    UPDATE deposits 
    SET status = 'expired' 
    WHERE status = 'pending' 
    AND expires_at < NOW();
END;
$$ LANGUAGE plpgsql;

-- Function to auto-finalize orders
CREATE OR REPLACE FUNCTION auto_finalize_orders()
RETURNS void AS $$
DECLARE
    order_row RECORD;
BEGIN
    FOR order_row IN 
        SELECT o.id, e.id as escrow_id, e.amount_xmr, o.vendor_id
        FROM orders o
        JOIN escrows e ON e.order_id = o.id
        WHERE o.status = 'shipped'
        AND o.autofinalize_at < NOW()
        AND e.status = 'held'
    LOOP
        -- Update order status
        UPDATE orders SET status = 'auto_finalized', completed_at = NOW() WHERE id = order_row.id;
        
        -- Release escrow to vendor
        UPDATE escrows SET status = 'released_vendor', released_at = NOW() WHERE id = order_row.escrow_id;
        
        -- Credit vendor balance
        UPDATE users SET balance_xmr = balance_xmr + order_row.amount_xmr WHERE id = order_row.vendor_id;
        
        -- Log the action
        INSERT INTO audit_log (action, entity_type, entity_id, details)
        VALUES ('auto_finalize', 'order', order_row.id, '{"reason": "autofinalize_timeout"}');
    END LOOP;
END;
$$ LANGUAGE plpgsql;

-- ============================================
-- INITIAL DATA
-- ============================================

-- Insert system user for system messages
INSERT INTO users (id, username, pgp_fingerprint, pgp_public_key, account_tier)
VALUES (
    '00000000-0000-0000-0000-000000000001',
    'system',
    '0000000000000000000000000000000000000000',
    'SYSTEM USER',
    'admin'
);

COMMENT ON TABLE users IS 'User accounts with PGP authentication';
COMMENT ON TABLE orders IS 'Marketplace orders with escrow';
COMMENT ON TABLE escrows IS 'Funds held in escrow until order completion';
COMMENT ON TABLE disputes IS 'Order disputes for resolution';
COMMENT ON TABLE deposits IS 'XMR deposit addresses with 3-hour expiry';
COMMENT ON TABLE messages IS 'Encrypted messages between users';
