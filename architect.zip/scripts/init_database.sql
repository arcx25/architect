-- ARCHITECT Market Database Schema
-- Zero JavaScript | PGP-Only Auth | Monero Payments

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    username VARCHAR(20) UNIQUE NOT NULL,
    pgp_fingerprint VARCHAR(40) UNIQUE NOT NULL,
    pgp_public_key TEXT NOT NULL,
    account_tier VARCHAR(20) DEFAULT 'buyer' CHECK (account_tier IN ('buyer', 'vendor', 'admin')),
    balance_atomic BIGINT DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    last_login TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    is_active BOOLEAN DEFAULT TRUE
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_users_username ON users(username);
CREATE INDEX IF NOT EXISTS idx_users_fingerprint ON users(pgp_fingerprint);
CREATE INDEX IF NOT EXISTS idx_users_tier ON users(account_tier);

-- Vendor applications table
CREATE TABLE IF NOT EXISTS vendor_applications (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    deposit_id UUID,
    description TEXT,
    status VARCHAR(20) DEFAULT 'pending_payment' CHECK (status IN ('pending_payment', 'pending_review', 'approved', 'rejected')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    reviewed_at TIMESTAMP WITH TIME ZONE
);

-- Storefronts table
CREATE TABLE IF NOT EXISTS storefronts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    vendor_id UUID UNIQUE REFERENCES users(id) ON DELETE CASCADE,
    name VARCHAR(100),
    description TEXT,
    banner_url TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Products table
CREATE TABLE IF NOT EXISTS products (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    vendor_id UUID REFERENCES users(id) ON DELETE CASCADE,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    price_atomic BIGINT NOT NULL,
    category VARCHAR(50),
    stock INTEGER DEFAULT -1,  -- -1 = unlimited
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_products_vendor ON products(vendor_id);
CREATE INDEX IF NOT EXISTS idx_products_category ON products(category);
CREATE INDEX IF NOT EXISTS idx_products_active ON products(is_active);

-- Deposits table (single-use addresses with 3-hour expiry)
CREATE TABLE IF NOT EXISTS deposits (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    address VARCHAR(106) NOT NULL,  -- XMR integrated address
    payment_id VARCHAR(16) NOT NULL,
    expected_amount BIGINT,
    received_amount BIGINT DEFAULT 0,
    purpose VARCHAR(50) DEFAULT 'wallet' CHECK (purpose IN ('wallet', 'vendor_upgrade', 'order', 'subscription')),
    reference_id UUID,
    status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'confirming', 'confirmed', 'expired', 'failed')),
    confirmations INTEGER DEFAULT 0,
    tx_hash VARCHAR(64),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    expires_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() + INTERVAL '3 hours',
    confirmed_at TIMESTAMP WITH TIME ZONE
);

CREATE INDEX IF NOT EXISTS idx_deposits_user ON deposits(user_id);
CREATE INDEX IF NOT EXISTS idx_deposits_address ON deposits(address);
CREATE INDEX IF NOT EXISTS idx_deposits_payment_id ON deposits(payment_id);
CREATE INDEX IF NOT EXISTS idx_deposits_status ON deposits(status);
CREATE INDEX IF NOT EXISTS idx_deposits_expires ON deposits(expires_at);

-- Orders table
CREATE TABLE IF NOT EXISTS orders (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    buyer_id UUID REFERENCES users(id) ON DELETE SET NULL,
    vendor_id UUID REFERENCES users(id) ON DELETE SET NULL,
    product_id UUID REFERENCES products(id) ON DELETE SET NULL,
    deposit_id UUID REFERENCES deposits(id) ON DELETE SET NULL,
    quantity INTEGER DEFAULT 1,
    price_atomic BIGINT NOT NULL,
    status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'paid', 'shipped', 'delivered', 'disputed', 'cancelled', 'refunded')),
    encrypted_shipping TEXT,  -- PGP encrypted shipping info
    encrypted_notes TEXT,     -- PGP encrypted order notes
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    paid_at TIMESTAMP WITH TIME ZONE,
    shipped_at TIMESTAMP WITH TIME ZONE,
    delivered_at TIMESTAMP WITH TIME ZONE
);

CREATE INDEX IF NOT EXISTS idx_orders_buyer ON orders(buyer_id);
CREATE INDEX IF NOT EXISTS idx_orders_vendor ON orders(vendor_id);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);

-- Messages table (PGP encrypted)
CREATE TABLE IF NOT EXISTS messages (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    sender_id UUID REFERENCES users(id) ON DELETE SET NULL,
    recipient_id UUID REFERENCES users(id) ON DELETE CASCADE,
    encrypted_content TEXT NOT NULL,  -- PGP encrypted message
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_messages_recipient ON messages(recipient_id);
CREATE INDEX IF NOT EXISTS idx_messages_sender ON messages(sender_id);
CREATE INDEX IF NOT EXISTS idx_messages_unread ON messages(recipient_id, is_read) WHERE NOT is_read;

-- Sessions table (optional, can use Redis instead)
CREATE TABLE IF NOT EXISTS sessions (
    id VARCHAR(64) PRIMARY KEY,
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    expires_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() + INTERVAL '30 minutes',
    ip_hash VARCHAR(64)  -- Hashed IP for security
);

CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_sessions_expires ON sessions(expires_at);

-- Challenges table (for PGP auth)
CREATE TABLE IF NOT EXISTS challenges (
    id VARCHAR(64) PRIMARY KEY,
    username VARCHAR(20) NOT NULL,
    challenge_hash VARCHAR(64) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    expires_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() + INTERVAL '5 minutes'
);

CREATE INDEX IF NOT EXISTS idx_challenges_username ON challenges(username);
CREATE INDEX IF NOT EXISTS idx_challenges_expires ON challenges(expires_at);

-- POW bypass tokens
CREATE TABLE IF NOT EXISTS pow_bypasses (
    token VARCHAR(64) PRIMARY KEY,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    expires_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() + INTERVAL '1 hour'
);

CREATE INDEX IF NOT EXISTS idx_pow_bypasses_expires ON pow_bypasses(expires_at);

-- Function to clean up expired records
CREATE OR REPLACE FUNCTION cleanup_expired_records()
RETURNS void AS $$
BEGIN
    -- Clean up expired deposits
    UPDATE deposits SET status = 'expired' 
    WHERE status = 'pending' AND expires_at < NOW();
    
    -- Clean up expired sessions
    DELETE FROM sessions WHERE expires_at < NOW();
    
    -- Clean up expired challenges
    DELETE FROM challenges WHERE expires_at < NOW();
    
    -- Clean up expired POW bypasses
    DELETE FROM pow_bypasses WHERE expires_at < NOW();
END;
$$ LANGUAGE plpgsql;

-- Create a system user for automated messages
INSERT INTO users (id, username, pgp_fingerprint, pgp_public_key, account_tier)
VALUES (
    '00000000-0000-0000-0000-000000000001',
    'system',
    '0000000000000000000000000000000000000000',
    'SYSTEM',
    'admin'
) ON CONFLICT (id) DO NOTHING;

-- Grant permissions
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO architect;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO architect;
