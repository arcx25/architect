/**
 * ARCHITECT Market - Remote Deployment Script
 * Deploys the application to a remote server via SSH/SCP
 *
 * This script runs in Node.js and handles:
 * - SSH connection to remote server
 * - File transfer via SCP
 * - Remote command execution
 * - Database initialization
 * - Service setup and startup
 *
 * Usage: node scripts/deploy-to-server.js
 *
 * Required environment variables:
 * - DEPLOY_HOST: Remote server IP/hostname
 * - DEPLOY_USER: SSH username (default: root)
 * - DEPLOY_KEY: SSH private key (base64 encoded) or path to key file
 * - DEPLOY_PASSWORD: SSH password (if not using key)
 */

import { Client } from "ssh2"
import { readFileSync, readdirSync, statSync, existsSync } from "fs"
import { join, relative, dirname } from "path"
import { fileURLToPath } from "url"

const __filename = fileURLToPath(import.meta.url)
const __dirname = dirname(__filename)

// ============================================
// Configuration
// ============================================

const CONFIG = {
  host: process.env.DEPLOY_HOST || "38.54.24.253",
  port: Number.parseInt(process.env.DEPLOY_PORT || "22"),
  username: process.env.DEPLOY_USER || "root",
  privateKey: process.env.DEPLOY_KEY
    ? process.env.DEPLOY_KEY.startsWith("/")
      ? readFileSync(process.env.DEPLOY_KEY, "utf8")
      : Buffer.from(process.env.DEPLOY_KEY, "base64").toString("utf8")
    : null,
  password: process.env.DEPLOY_PASSWORD || null,

  remoteAppDir: "/var/lib/architect",
  remoteConfigDir: "/etc/architect",
  remoteLogDir: "/var/log/architect",
  remoteVenvDir: "/var/lib/architect/venv",
  remoteGpgDir: "/var/lib/architect/gnupg",
}

// Colors for console output
const colors = {
  reset: "\x1b[0m",
  bright: "\x1b[1m",
  red: "\x1b[31m",
  green: "\x1b[32m",
  yellow: "\x1b[33m",
  blue: "\x1b[34m",
  magenta: "\x1b[35m",
  cyan: "\x1b[36m",
}

// ============================================
// Logging Functions
// ============================================

function timestamp() {
  return new Date().toISOString().replace("T", " ").split(".")[0]
}

function log(level, message) {
  const levelColors = {
    INFO: colors.green,
    WARN: colors.yellow,
    ERROR: colors.red,
    DEBUG: colors.blue,
    SUCCESS: colors.cyan,
    STEP: colors.magenta,
  }
  console.log(`${levelColors[level] || colors.reset}[${timestamp()}] [${level}]${colors.reset} ${message}`)
}

const logInfo = (msg) => log("INFO", msg)
const logWarn = (msg) => log("WARN", msg)
const logError = (msg) => log("ERROR", msg)
const logDebug = (msg) => log("DEBUG", msg)
const logSuccess = (msg) => log("SUCCESS", msg)
const logStep = (msg) => log("STEP", msg)

function printBanner() {
  console.log(`${colors.cyan}
╔═══════════════════════════════════════════════════════════════╗
║                                                               ║
║      ╔═══╗    RCHITECT                                        ║
║      ║ A ║                                                    ║
║      ╚═══╝    Remote Deployment Pipeline                      ║
║                                                               ║
║      Zero JavaScript | PGP-Only Auth | Monero Payments        ║
║      v0 -> Remote Server Deployment                           ║
╚═══════════════════════════════════════════════════════════════╝
${colors.reset}`)
}

// ============================================
// SSH/SCP Functions
// ============================================

class DeploymentPipeline {
  constructor(config) {
    this.config = config
    this.conn = new Client()
    this.connected = false
  }

  async connect() {
    return new Promise((resolve, reject) => {
      logStep("Connecting to remote server...")
      logInfo(`Host: ${this.config.host}:${this.config.port}`)
      logInfo(`User: ${this.config.username}`)
      logInfo(`Auth: ${this.config.privateKey ? "SSH Key" : "Password"}`)

      this.conn.on("ready", () => {
        this.connected = true
        logSuccess("SSH connection established")
        resolve()
      })

      this.conn.on("error", (err) => {
        logError(`SSH connection failed: ${err.message}`)
        reject(err)
      })

      const connConfig = {
        host: this.config.host,
        port: this.config.port,
        username: this.config.username,
      }

      if (this.config.privateKey) {
        connConfig.privateKey = this.config.privateKey
      } else if (this.config.password) {
        connConfig.password = this.config.password
      } else {
        reject(new Error("No authentication method provided. Set DEPLOY_KEY or DEPLOY_PASSWORD"))
        return
      }

      this.conn.connect(connConfig)
    })
  }

  async exec(command, options = {}) {
    return new Promise((resolve, reject) => {
      if (!this.connected) {
        reject(new Error("Not connected to server"))
        return
      }

      const { silent = false, ignoreError = false } = options
      if (!silent) logDebug(`Executing: ${command}`)

      this.conn.exec(command, (err, stream) => {
        if (err) {
          reject(err)
          return
        }

        let stdout = ""
        let stderr = ""

        stream.on("close", (code) => {
          if (code !== 0 && !ignoreError) {
            if (!silent) logError(`Command failed with code ${code}: ${stderr}`)
            reject(new Error(`Command failed: ${stderr}`))
          } else {
            resolve({ stdout: stdout.trim(), stderr: stderr.trim(), code })
          }
        })

        stream.on("data", (data) => {
          stdout += data.toString()
          if (!silent && options.stream) process.stdout.write(data)
        })

        stream.stderr.on("data", (data) => {
          stderr += data.toString()
          if (!silent && options.stream) process.stderr.write(data)
        })
      })
    })
  }

  async sftp() {
    return new Promise((resolve, reject) => {
      this.conn.sftp((err, sftp) => {
        if (err) reject(err)
        else resolve(sftp)
      })
    })
  }

  async uploadFile(sftp, localPath, remotePath) {
    return new Promise((resolve, reject) => {
      const content = readFileSync(localPath)

      sftp.writeFile(remotePath, content, (err) => {
        if (err) reject(err)
        else resolve()
      })
    })
  }

  async uploadDirectory(sftp, localDir, remoteDir) {
    const files = this.getAllFiles(localDir)
    let uploaded = 0

    for (const file of files) {
      const relativePath = relative(localDir, file)
      const remotePath = join(remoteDir, relativePath).replace(/\\/g, "/")
      const remoteFileDir = dirname(remotePath)

      // Create remote directory
      await this.exec(`mkdir -p "${remoteFileDir}"`, { silent: true, ignoreError: true })

      // Upload file
      await this.uploadFile(sftp, file, remotePath)
      uploaded++

      if (uploaded % 10 === 0 || uploaded === files.length) {
        logInfo(`Uploaded ${uploaded}/${files.length} files`)
      }
    }

    return uploaded
  }

  getAllFiles(dir, files = []) {
    const entries = readdirSync(dir)

    for (const entry of entries) {
      const fullPath = join(dir, entry)
      const stat = statSync(fullPath)

      if (stat.isDirectory()) {
        this.getAllFiles(fullPath, files)
      } else {
        files.push(fullPath)
      }
    }

    return files
  }

  async disconnect() {
    if (this.connected) {
      this.conn.end()
      this.connected = false
      logInfo("SSH connection closed")
    }
  }
}

// ============================================
// Deployment Steps
// ============================================

async function deployArchitect() {
  printBanner()

  const pipeline = new DeploymentPipeline(CONFIG)

  try {
    // Step 1: Connect
    await pipeline.connect()

    // Step 2: Validate server
    logStep("Step 1/10: Validating server environment...")
    const { stdout: osInfo } = await pipeline.exec("cat /etc/os-release | head -2")
    logInfo(`Server OS: ${osInfo.replace(/\n/g, " ")}`)

    const { stdout: memory } = await pipeline.exec("free -h | awk '/^Mem:/ {print $2}'")
    logInfo(`Available memory: ${memory}`)

    // Step 3: Install dependencies
    logStep("Step 2/10: Installing system dependencies...")
    await pipeline.exec("apt-get update", { stream: true })
    await pipeline.exec(
      "apt-get install -y python3 python3-pip python3-venv postgresql postgresql-contrib redis-server tor gnupg nginx",
      { stream: true },
    )
    logSuccess("System dependencies installed")

    // Step 4: Create directories
    logStep("Step 3/10: Creating application directories...")
    await pipeline.exec(
      `mkdir -p ${CONFIG.remoteAppDir} ${CONFIG.remoteConfigDir} ${CONFIG.remoteLogDir} ${CONFIG.remoteGpgDir}`,
    )
    await pipeline.exec(`chmod 700 ${CONFIG.remoteGpgDir}`)
    logSuccess("Directories created")

    // Step 5: Upload application files
    logStep("Step 4/10: Uploading application files...")
    const sftp = await pipeline.sftp()

    const scriptsDir = join(__dirname)
    const uploadCount = await pipeline.uploadDirectory(sftp, scriptsDir, CONFIG.remoteAppDir)
    logSuccess(`Uploaded ${uploadCount} files`)

    // Upload requirements.txt from root
    const requirementsPath = join(__dirname, "..", "requirements.txt")
    if (existsSync(requirementsPath)) {
      await pipeline.uploadFile(sftp, requirementsPath, `${CONFIG.remoteAppDir}/requirements.txt`)
      logSuccess("Uploaded requirements.txt")
    }

    // Upload deploy.sh from root
    const deployShPath = join(__dirname, "..", "deploy.sh")
    if (existsSync(deployShPath)) {
      await pipeline.uploadFile(sftp, deployShPath, `${CONFIG.remoteAppDir}/deploy.sh`)
      await pipeline.exec(`chmod +x ${CONFIG.remoteAppDir}/deploy.sh`)
      logSuccess("Uploaded deploy.sh")
    }

    sftp.end()

    // Step 6: Create Python virtual environment
    logStep("Step 5/10: Setting up Python virtual environment...")
    await pipeline.exec(`python3 -m venv ${CONFIG.remoteVenvDir}`, { stream: true })
    await pipeline.exec(`${CONFIG.remoteVenvDir}/bin/pip install --upgrade pip`, { stream: true })
    await pipeline.exec(`${CONFIG.remoteVenvDir}/bin/pip install -r ${CONFIG.remoteAppDir}/requirements.txt`, {
      stream: true,
    })
    logSuccess("Python environment configured")

    // Step 7: Setup PostgreSQL
    logStep("Step 6/10: Configuring PostgreSQL database...")
    await pipeline.exec("systemctl enable postgresql && systemctl start postgresql", { ignoreError: true })
    await pipeline.exec(
      `sudo -u postgres psql -c "CREATE USER architect WITH PASSWORD 'architect_secret_$(openssl rand -hex 8)';" || true`,
      { ignoreError: true },
    )
    await pipeline.exec(`sudo -u postgres psql -c "CREATE DATABASE architect OWNER architect;" || true`, {
      ignoreError: true,
    })

    // Run migrations
    const migrationFiles = ["001_init_schema.sql", "002_seed_demo_data.sql", "init_database.sql"]
    for (const file of migrationFiles) {
      const filePath = `${CONFIG.remoteAppDir}/${file}`
      const { code } = await pipeline.exec(`test -f ${filePath} && echo exists`, { silent: true, ignoreError: true })
      if (code === 0) {
        await pipeline.exec(`sudo -u postgres psql -d architect -f ${filePath}`, { stream: true, ignoreError: true })
        logInfo(`Applied migration: ${file}`)
      }
    }
    logSuccess("Database configured")

    // Step 8: Generate server PGP keypair
    logStep("Step 7/10: Generating server PGP keypair...")
    const gpgBatchConfig = `
%echo Generating ARCHITECT server key
Key-Type: RSA
Key-Length: 4096
Subkey-Type: RSA
Subkey-Length: 4096
Name-Real: ARCHITECT Market
Name-Email: architect@onion.local
Expire-Date: 0
%no-protection
%commit
%echo Key generation complete
`
    await pipeline.exec(`echo '${gpgBatchConfig}' > /tmp/gpg-batch.conf`)
    await pipeline.exec(`GNUPGHOME=${CONFIG.remoteGpgDir} gpg --batch --gen-key /tmp/gpg-batch.conf`, {
      stream: true,
      ignoreError: true,
    })
    await pipeline.exec("rm /tmp/gpg-batch.conf")

    const { stdout: keyId } = await pipeline.exec(
      `GNUPGHOME=${CONFIG.remoteGpgDir} gpg --list-keys --keyid-format SHORT | grep -oP '(?<=rsa4096/)[A-F0-9]+' | head -1`,
      { ignoreError: true },
    )
    if (keyId) {
      logSuccess(`Server PGP key generated: ${keyId}`)
    }

    // Step 9: Configure and start services
    logStep("Step 8/10: Configuring systemd service...")
    const systemdService = `[Unit]
Description=ARCHITECT Market Application
After=network.target postgresql.service redis.service

[Service]
Type=simple
User=www-data
Group=www-data
WorkingDirectory=${CONFIG.remoteAppDir}
Environment="PATH=${CONFIG.remoteVenvDir}/bin"
Environment="GNUPGHOME=${CONFIG.remoteGpgDir}"
Environment="DATABASE_URL=postgresql://architect:architect@localhost/architect"
Environment="REDIS_URL=redis://localhost:6379"
ExecStart=${CONFIG.remoteVenvDir}/bin/uvicorn app.main:app --host 127.0.0.1 --port 8000
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
`
    await pipeline.exec(`echo '${systemdService}' > /etc/systemd/system/architect.service`)
    await pipeline.exec("systemctl daemon-reload")
    await pipeline.exec("systemctl enable architect")
    logSuccess("Systemd service configured")

    // Step 9: Configure Tor hidden service
    logStep("Step 9/10: Configuring Tor hidden service...")
    const torConfig = `
HiddenServiceDir /var/lib/tor/architect/
HiddenServicePort 80 127.0.0.1:8000
`
    await pipeline.exec(`echo '${torConfig}' >> /etc/tor/torrc`)
    await pipeline.exec("systemctl restart tor", { ignoreError: true })

    // Wait for onion address
    await pipeline.exec("sleep 5")
    const { stdout: onionAddr } = await pipeline.exec(
      'cat /var/lib/tor/architect/hostname 2>/dev/null || echo "pending"',
      { ignoreError: true },
    )
    logInfo(`Onion address: ${onionAddr}`)

    // Step 10: Start application
    logStep("Step 10/10: Starting ARCHITECT Market...")
    await pipeline.exec("chown -R www-data:www-data " + CONFIG.remoteAppDir)
    await pipeline.exec("systemctl start architect", { stream: true })

    // Verify
    await pipeline.exec("sleep 3")
    const { stdout: status } = await pipeline.exec("systemctl is-active architect", { ignoreError: true })

    if (status.trim() === "active") {
      logSuccess("ARCHITECT Market is running!")
    } else {
      logWarn("Service may not be running. Check logs with: journalctl -u architect -f")
    }

    // Print summary
    console.log(`
${colors.cyan}════════════════════════════════════════════════════════════════${colors.reset}
${colors.green}${colors.bright}DEPLOYMENT COMPLETE${colors.reset}

${colors.cyan}Application:${colors.reset} ${CONFIG.remoteAppDir}
${colors.cyan}Logs:${colors.reset}        journalctl -u architect -f
${colors.cyan}Status:${colors.reset}      systemctl status architect
${colors.cyan}Onion:${colors.reset}       ${onionAddr}

${colors.yellow}Next Steps:${colors.reset}
1. Access via Tor: http://${onionAddr}
2. Monitor logs: journalctl -u architect -f
3. Check status: systemctl status architect
${colors.cyan}════════════════════════════════════════════════════════════════${colors.reset}
`)
  } catch (error) {
    logError(`Deployment failed: ${error.message}`)
    console.error(error)
    process.exit(1)
  } finally {
    await pipeline.disconnect()
  }
}

// ============================================
// Main Entry Point
// ============================================

console.log("ARCHITECT Market Deployment Pipeline")
console.log("====================================")
console.log("")
console.log("This script will deploy the application to your remote server.")
console.log("")
console.log("Required environment variables:")
console.log("  DEPLOY_HOST     - Remote server IP (default: 38.54.24.253)")
console.log("  DEPLOY_USER     - SSH username (default: root)")
console.log("  DEPLOY_KEY      - SSH private key (base64) or path to key file")
console.log("  DEPLOY_PASSWORD - SSH password (if not using key)")
console.log("")

// Check if we have authentication
if (!CONFIG.privateKey && !CONFIG.password) {
  console.log(`${colors.red}ERROR: No authentication configured.${colors.reset}`)
  console.log("Please set either DEPLOY_KEY or DEPLOY_PASSWORD environment variable.")
  console.log("")
  console.log("Example with SSH key:")
  console.log("  export DEPLOY_KEY=$(base64 -w0 ~/.ssh/id_rsa)")
  console.log("  node scripts/deploy-to-server.js")
  console.log("")
  console.log("Example with password:")
  console.log('  export DEPLOY_PASSWORD="your-password"')
  console.log("  node scripts/deploy-to-server.js")
  process.exit(1)
}

// Run deployment
deployArchitect().catch((err) => {
  console.error("Fatal error:", err)
  process.exit(1)
})
