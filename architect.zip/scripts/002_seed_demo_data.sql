-- ARCHITECT Market Demo Data
-- For development and testing only

-- Demo vendors
INSERT INTO users (id, username, pgp_fingerprint, pgp_public_key, account_tier, rating, total_sales)
VALUES 
    ('11111111-1111-1111-1111-111111111111', 'cryptovault', 'DEMO000000000000000000000000000000000001', 'DEMO PGP KEY', 'vendor', 4.8, 127),
    ('22222222-2222-2222-2222-222222222222', 'ghostnet', 'DEMO000000000000000000000000000000000002', 'DEMO PGP KEY', 'vendor', 4.9, 89),
    ('33333333-3333-3333-3333-333333333333', 'shadowops', 'DEMO000000000000000000000000000000000003', 'DEMO PGP KEY', 'vendor', 5.0, 34),
    ('44444444-4444-4444-4444-444444444444', 'securehardware', 'DEMO000000000000000000000000000000000004', 'DEMO PGP KEY', 'vendor', 4.6, 78);

-- Demo products
INSERT INTO products (id, vendor_id, title, description, price_xmr, category, stock, rating, total_sales, shipping_options)
VALUES
    ('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', '11111111-1111-1111-1111-111111111111', 
     'Premium Security Suite', 
     'Complete digital security toolkit with encryption tools, secure communication protocols, and privacy-focused utilities. Includes lifetime updates.',
     0.25, 'Digital Goods', 999, 4.8, 127, '["Digital Delivery"]'),
     
    ('bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', '22222222-2222-2222-2222-222222222222',
     'Anonymous VPN Access - 12 Months',
     'Premium VPN service with strict no-logs policy, multi-hop connections, dedicated IPs, and Tor over VPN support. Accepts XMR only.',
     0.15, 'Services', 50, 4.9, 89, '["Digital Delivery"]'),
     
    ('cccccccc-cccc-cccc-cccc-cccccccccccc', '11111111-1111-1111-1111-111111111111',
     'Secure Messaging Protocol License',
     'Custom E2E encrypted messaging solution with forward secrecy, self-destructing messages, and decentralized architecture.',
     0.50, 'Software', 999, 4.7, 56, '["Digital Delivery"]'),
     
    ('dddddddd-dddd-dddd-dddd-dddddddddddd', '33333333-3333-3333-3333-333333333333',
     'Privacy Audit Service',
     'Complete digital footprint analysis and cleanup. Our experts will identify and help remove your online traces.',
     1.20, 'Services', 10, 5.0, 34, '["Consultation"]'),
     
    ('eeeeeeee-eeee-eeee-eeee-eeeeeeeeeeee', '44444444-4444-4444-4444-444444444444',
     'Hardware Security Key Bundle (3x)',
     'Set of 3 FIDO2/WebAuthn compatible security keys for ultimate account protection. Tamper-evident packaging.',
     0.35, 'Physical Goods', 25, 4.6, 78, '["Worldwide Shipping", "Express Shipping"]'),
     
    ('ffffffff-ffff-ffff-ffff-ffffffffffff', '44444444-4444-4444-4444-444444444444',
     'Encrypted Storage Drive 512GB',
     'Hardware-encrypted USB drive with tamper-evident casing, dead-man switch, and secure erase functionality.',
     0.80, 'Physical Goods', 15, 4.9, 42, '["Worldwide Shipping"]');
