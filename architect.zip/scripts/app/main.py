"""
ARCHITECT Market - Complete FastAPI Application
Zero JavaScript | PGP-Only Auth | Monero Payments
Full Escrow System | Dispute Resolution | PoW Gate
"""
import os
import secrets
import hashlib
import re
import json
import base64
import io
import random
import subprocess
from datetime import datetime, timedelta
from typing import Optional, Dict, List, Any, Tuple
from decimal import Decimal
from enum import Enum
from dataclasses import dataclass, field

from fastapi import FastAPI, Request, Form, HTTPException, Response, Query, Cookie
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from starlette.middleware.sessions import SessionMiddleware

try:
    import gnupg
    HAS_GNUPG = True
except ImportError:
    HAS_GNUPG = False
    gnupg = None

try:
    import qrcode
    HAS_QRCODE = True
except ImportError:
    HAS_QRCODE = False

# ============================================
# Configuration
# ============================================

app = FastAPI(title="ARCHITECT Market", docs_url=None, redoc_url=None)

app.add_middleware(
    SessionMiddleware,
    secret_key=os.environ.get("FLASK_SECRET_KEY", secrets.token_hex(32)),
    session_cookie="architect_session",
    max_age=1800,
    same_site="strict",
    https_only=os.environ.get("FLASK_DEBUG", "0") != "1"
)

# Static files
os.makedirs("scripts/app/static", exist_ok=True)
app.mount("/static", StaticFiles(directory="scripts/app/static"), name="static")

templates = Jinja2Templates(directory="scripts/app/templates")

# GPG Configuration - Mock GPG class when gnupg not available
GPG_HOME = os.environ.get("GPG_HOME", "/tmp/architect_gnupg")

class MockGPG:
    """Mock GPG implementation for preview environment"""
    def __init__(self):
        self.encoding = 'utf-8'
        self._keys = {}
        self._key_counter = 0
    
    def gen_key(self, input_data):
        """Generate a mock key"""
        self._key_counter += 1
        fingerprint = hashlib.sha256(f"key_{self._key_counter}_{secrets.token_hex(16)}".encode()).hexdigest()[:40].upper()
        
        class KeyResult:
            def __init__(self, fp):
                self.fingerprint = fp
                self.ok = True
        
        self._keys[fingerprint] = {
            'fingerprint': fingerprint,
            'keyid': fingerprint[-16:],
            'uids': ['ARCHITECT Market Server <server@architect.onion>']
        }
        return KeyResult(fingerprint)
    
    def gen_key_input(self, **kwargs):
        return str(kwargs)
    
    def list_keys(self, secret=False):
        return list(self._keys.values())
    
    def import_keys(self, key_data):
        fingerprint = hashlib.sha256(key_data.encode()).hexdigest()[:40].upper()
        
        class ImportResult:
            def __init__(self, fp):
                self.fingerprints = [fp]
                self.count = 1
        
        self._keys[fingerprint] = {
            'fingerprint': fingerprint,
            'keyid': fingerprint[-16:],
            'uids': ['Imported Key']
        }
        return ImportResult(fingerprint)
    
    def export_keys(self, keyid, armor=True):
        return f"""-----BEGIN PGP PUBLIC KEY BLOCK-----
Version: ARCHITECT Mock GPG

mQINBGV...mock_key_data_for_{keyid}...
-----END PGP PUBLIC KEY BLOCK-----"""
    
    def encrypt(self, data, recipients, sign=None, passphrase=None, armor=True, always_trust=True):
        """Mock encryption - creates deterministic but reversible output for demo"""
        encoded = base64.b64encode(data.encode() if isinstance(data, str) else data).decode()
        
        class EncryptResult:
            def __init__(self, data):
                self.data = data
                self.ok = True
                self.status = 'encryption ok'
            def __str__(self):
                return self.data
        
        pgp_message = f"""-----BEGIN PGP MESSAGE-----
Version: ARCHITECT Market

{encoded}
-----END PGP MESSAGE-----"""
        return EncryptResult(pgp_message)
    
    def decrypt(self, data, passphrase=None, always_trust=True):
        """Mock decryption"""
        class DecryptResult:
            def __init__(self, data):
                self.data = data
                self.ok = True
            def __str__(self):
                return self.data
        
        # Extract base64 from PGP format
        if '-----BEGIN PGP MESSAGE-----' in str(data):
            lines = str(data).split('\n')
            b64_data = ''
            in_data = False
            for line in lines:
                if line.startswith('-----END'):
                    break
                if in_data and line.strip():
                    b64_data += line.strip()
                if line == '':
                    in_data = True
            try:
                decoded = base64.b64decode(b64_data).decode()
                return DecryptResult(decoded)
            except:
                pass
        return DecryptResult(str(data))
    
    def sign(self, data, keyid=None, passphrase=None, detach=True, clearsign=False):
        """Mock signing"""
        sig_hash = hashlib.sha256(f"{data}{keyid}".encode()).hexdigest()[:32]
        
        class SignResult:
            def __init__(self, data, sig):
                self.data = data
                self.fingerprint = sig
                self.ok = True
            def __str__(self):
                return self.data
        
        if clearsign:
            signed = f"""-----BEGIN PGP SIGNED MESSAGE-----
Hash: SHA256

{data}
-----BEGIN PGP SIGNATURE-----

iQIz...{sig_hash}...
-----END PGP SIGNATURE-----"""
        else:
            signed = f"""-----BEGIN PGP SIGNATURE-----

iQIz...{sig_hash}...
-----END PGP SIGNATURE-----"""
        
        return SignResult(signed, sig_hash)
    
    def verify(self, data, sig=None):
        """Mock verification - always returns valid for demo"""
        class VerifyResult:
            def __init__(self):
                self.valid = True
                self.fingerprint = "MOCK_FINGERPRINT"
                self.trust_level = 4
                self.trust_text = "TRUST_ULTIMATE"
        return VerifyResult()


if HAS_GNUPG:
    os.makedirs(GPG_HOME, exist_ok=True)
    gpg = gnupg.GPG(gnupghome=GPG_HOME)
    gpg.encoding = 'utf-8'
else:
    gpg = MockGPG()

# Server key configuration
SERVER_KEY_ID: Optional[str] = None
SERVER_KEY_FINGERPRINT: Optional[str] = None
SERVER_KEY_PASSPHRASE = os.environ.get("SERVER_KEY_PASSPHRASE", secrets.token_hex(32))

# ============================================
# Enums and Constants
# ============================================

class OrderStatus(str, Enum):
    PENDING_PAYMENT = "pending_payment"
    PAID = "paid"
    PROCESSING = "processing"
    SHIPPED = "shipped"
    DELIVERED = "delivered"
    DISPUTED = "disputed"
    COMPLETED = "completed"
    CANCELLED = "cancelled"
    REFUNDED = "refunded"
    AUTO_FINALIZED = "auto_finalized"

class DisputeStatus(str, Enum):
    OPEN = "open"
    VENDOR_RESPONSE = "vendor_response"
    BUYER_RESPONSE = "buyer_response"
    ADMIN_REVIEW = "admin_review"
    RESOLVED_BUYER = "resolved_buyer"
    RESOLVED_VENDOR = "resolved_vendor"
    RESOLVED_SPLIT = "resolved_split"

class DepositStatus(str, Enum):
    PENDING = "pending"
    CONFIRMING = "confirming"
    CONFIRMED = "confirmed"
    EXPIRED = "expired"

class EscrowStatus(str, Enum):
    HELD = "held"
    RELEASED_TO_VENDOR = "released_vendor"
    REFUNDED_TO_BUYER = "refunded_buyer"
    SPLIT = "split"

class AccountTier(str, Enum):
    BUYER = "buyer"
    VENDOR = "vendor"
    ADMIN = "admin"

# Fee structure
VENDOR_UPGRADE_FEE_USD = Decimal("1000")
MARKETPLACE_FEE_PERCENT = Decimal("5")
ESCROW_HOLD_DAYS = 14
AUTOFINALIZE_DAYS = 21
DEPOSIT_EXPIRY_HOURS = 3

# ============================================
# Data Classes
# ============================================

@dataclass
class User:
    id: str
    username: str
    pgp_fingerprint: str
    pgp_public_key: str
    account_tier: AccountTier
    created_at: datetime
    last_login: Optional[datetime] = None
    balance_xmr: Decimal = Decimal("0")
    escrow_balance_xmr: Decimal = Decimal("0")
    anti_phishing_phrase: str = ""
    canary_active: bool = True
    total_sales: int = 0
    total_purchases: int = 0
    rating: Decimal = Decimal("0")
    
@dataclass
class Product:
    id: str
    vendor_id: str
    vendor_name: str
    title: str
    description: str
    price_xmr: Decimal
    category: str
    stock: int
    rating: Decimal
    sales: int
    shipping_options: List[str]
    created_at: datetime
    is_active: bool = True
    images: List[str] = field(default_factory=list)

@dataclass
class Order:
    id: str
    buyer_id: str
    vendor_id: str
    product_id: str
    quantity: int
    price_xmr: Decimal
    total_xmr: Decimal
    fee_xmr: Decimal
    status: OrderStatus
    shipping_address_encrypted: str
    shipping_option: str
    created_at: datetime
    paid_at: Optional[datetime] = None
    shipped_at: Optional[datetime] = None
    delivered_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    autofinalize_at: Optional[datetime] = None
    tracking_encrypted: str = ""
    notes_encrypted: str = ""

@dataclass
class Escrow:
    id: str
    order_id: str
    buyer_id: str
    vendor_id: str
    amount_xmr: Decimal
    fee_xmr: Decimal
    status: EscrowStatus
    created_at: datetime
    released_at: Optional[datetime] = None

@dataclass
class Dispute:
    id: str
    order_id: str
    buyer_id: str
    vendor_id: str
    reason: str
    buyer_evidence: str
    vendor_response: str
    admin_notes: str
    status: DisputeStatus
    created_at: datetime
    resolved_at: Optional[datetime] = None
    resolution_amount_buyer: Decimal = Decimal("0")
    resolution_amount_vendor: Decimal = Decimal("0")

@dataclass
class Deposit:
    id: str
    user_id: str
    address: str
    payment_id: str
    expected_amount: Decimal
    received_amount: Decimal
    purpose: str
    reference_id: Optional[str]
    status: DepositStatus
    created_at: datetime
    expires_at: datetime
    confirmed_at: Optional[datetime] = None
    signed_details: str = ""

@dataclass
class Message:
    id: str
    sender_id: str
    recipient_id: str
    subject: str
    content_encrypted: str
    is_read: bool
    created_at: datetime

@dataclass
class PowChallenge:
    id: str
    answer: int
    instruction: str
    numbers: List[int]
    expires_at: datetime

# ============================================
# In-Memory Data Stores
# ============================================

challenges_store: Dict[str, dict] = {}
pgp_store: Dict[str, dict] = {}
sessions_store: Dict[str, str] = {}
users_store: Dict[str, User] = {}
products_store: Dict[str, Product] = {}
orders_store: Dict[str, Order] = {}
escrows_store: Dict[str, Escrow] = {}
disputes_store: Dict[str, Dispute] = {}
deposits_store: Dict[str, Deposit] = {}
messages_store: Dict[str, Message] = {}
pow_challenges_store: Dict[str, PowChallenge] = {}
pow_bypass_store: Dict[str, datetime] = {}
vendor_applications_store: Dict[str, dict] = {}

# ============================================
# Server Key Management
# ============================================

def init_server_keypair():
    """Generate or load the server's PGP keypair"""
    global SERVER_KEY_ID, SERVER_KEY_FINGERPRINT
    
    existing_keys = gpg.list_keys(True)
    server_keys = [k for k in existing_keys if 'ARCHITECT Market Server' in k.get('uids', [''])[0]]
    
    if server_keys:
        SERVER_KEY_FINGERPRINT = server_keys[0]['fingerprint']
        SERVER_KEY_ID = server_keys[0]['keyid']
        print(f"[ARCHITECT] Loaded server key: {SERVER_KEY_FINGERPRINT[-16:]}")
    else:
        print("[ARCHITECT] Generating server keypair (4096-bit RSA)...")
        input_data = gpg.gen_key_input(
            key_type="RSA",
            key_length=4096,
            name_real="ARCHITECT Market Server",
            name_email="server@architect.onion",
            name_comment="Server Signing Key",
            passphrase=SERVER_KEY_PASSPHRASE,
            expire_date='2y'
        )
        key = gpg.gen_key(input_data)
        if key:
            SERVER_KEY_FINGERPRINT = str(key)
            SERVER_KEY_ID = SERVER_KEY_FINGERPRINT[-16:]
            print(f"[ARCHITECT] Generated server key: {SERVER_KEY_FINGERPRINT}")
        else:
            print("[ARCHITECT] WARNING: Could not generate server key")


def get_server_public_key() -> str:
    """Export server's public key in ASCII armor format"""
    if not SERVER_KEY_FINGERPRINT:
        return ""
    return gpg.export_keys(SERVER_KEY_FINGERPRINT, armor=True)


def sign_message(message: str) -> str:
    """Sign a message with server's private key (clearsign)"""
    if not SERVER_KEY_ID:
        return message
    signed = gpg.sign(
        message,
        keyid=SERVER_KEY_ID,
        passphrase=SERVER_KEY_PASSPHRASE,
        clearsign=True
    )
    return str(signed) if signed else message


def sign_and_encrypt(message: str, recipient_fingerprint: str) -> str:
    """Sign message with server key, then encrypt for recipient"""
    if not SERVER_KEY_ID:
        encrypted = gpg.encrypt(message, recipient_fingerprint, always_trust=True, armor=True)
        return str(encrypted) if encrypted.ok else f"[Encryption failed: {encrypted.status}]"
    
    encrypted = gpg.encrypt(
        message,
        recipient_fingerprint,
        sign=SERVER_KEY_ID,
        passphrase=SERVER_KEY_PASSPHRASE,
        always_trust=True,
        armor=True
    )
    return str(encrypted) if encrypted.ok else f"[Encryption failed: {encrypted.status}]"


def encrypt_for_user(message: str, user_fingerprint: str) -> str:
    """Encrypt and sign a message for a user"""
    return sign_and_encrypt(message, user_fingerprint)


def import_user_key(pgp_public_key: str) -> Optional[str]:
    """Import a user's PGP public key and return fingerprint"""
    result = gpg.import_keys(pgp_public_key)
    if result.count > 0:
        return result.results[0].get('fingerprint')
    return None


# ============================================
# Utility Functions
# ============================================

def generate_id(prefix: str = "") -> str:
    """Generate a unique ID with optional prefix"""
    return f"{prefix}{secrets.token_hex(12)}"


def generate_architect_code() -> str:
    """Generate ARCHITECT challenge code"""
    return f"ARCHITECT_{secrets.token_urlsafe(48)}"


def generate_xmr_address() -> Tuple[str, str]:
    """Generate simulated XMR integrated address and payment ID"""
    payment_id = secrets.token_hex(8)
    # Simulated integrated address (in production, use monero-wallet-rpc)
    address = f"4{secrets.token_hex(47)}"
    return address, payment_id


def generate_qr_code_base64(data: str) -> str:
    """Generate QR code as base64 PNG"""
    if not HAS_QRCODE:
        return ""
    try:
        qr = qrcode.QRCode(version=1, box_size=10, border=4)
        qr.add_data(data)
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white")
        buffer = io.BytesIO()
        img.save(buffer, format='PNG')
        return base64.b64encode(buffer.getvalue()).decode()
    except Exception:
        return ""


def get_current_user(request: Request) -> Optional[User]:
    """Get current user from session"""
    session_token = request.cookies.get("architect_session")
    if session_token and session_token in sessions_store:
        user_id = sessions_store[session_token]
        return users_store.get(user_id)
    return None


def require_auth(request: Request) -> User:
    """Require authentication, raise exception if not logged in"""
    user = get_current_user(request)
    if not user:
        raise HTTPException(status_code=401, detail="Not authenticated")
    return user


def require_vendor(request: Request) -> User:
    """Require vendor account"""
    user = require_auth(request)
    if user.account_tier != AccountTier.VENDOR and user.account_tier != AccountTier.ADMIN:
        raise HTTPException(status_code=403, detail="Vendor access required")
    return user


def format_xmr(amount: Decimal) -> str:
    """Format XMR amount with 6 decimal places"""
    return f"{amount:.6f}"


def time_remaining(expires_at: datetime) -> str:
    """Calculate human-readable time remaining"""
    delta = expires_at - datetime.now()
    if delta.total_seconds() <= 0:
        return "Expired"
    hours, remainder = divmod(int(delta.total_seconds()), 3600)
    minutes, seconds = divmod(remainder, 60)
    if hours > 0:
        return f"{hours}h {minutes}m"
    return f"{minutes}m {seconds}s"


def get_xmr_price_usd() -> Decimal:
    """Get current XMR/USD price (simulated)"""
    return Decimal("150.00")


def usd_to_xmr(usd_amount: Decimal) -> Decimal:
    """Convert USD to XMR"""
    price = get_xmr_price_usd()
    return (usd_amount / price).quantize(Decimal("0.000001"))


def calculate_fee(amount_xmr: Decimal) -> Decimal:
    """Calculate marketplace fee"""
    return (amount_xmr * MARKETPLACE_FEE_PERCENT / 100).quantize(Decimal("0.000001"))


# ============================================
# Proof of Work Gate
# ============================================

def is_prime(n: int) -> bool:
    """Check if number is prime"""
    if n < 2:
        return False
    for i in range(2, int(n ** 0.5) + 1):
        if n % i == 0:
            return False
    return True


def generate_pow_challenge() -> PowChallenge:
    """Generate a PoW number grid challenge"""
    numbers = list(range(1, 17))
    random.shuffle(numbers)
    
    challenge_types = ['prime', 'square', 'even', 'greater', 'less']
    challenge_type = random.choice(challenge_types)
    
    if challenge_type == 'prime':
        primes = [n for n in numbers if is_prime(n)]
        target = random.choice(primes) if primes else 2
        instruction = f"Click the prime number: {target}"
    elif challenge_type == 'square':
        squares = [n for n in numbers if int(n ** 0.5) ** 2 == n]
        target = random.choice(squares) if squares else 1
        instruction = f"Click the perfect square: {target}"
    elif challenge_type == 'even':
        evens = [n for n in numbers if n % 2 == 0]
        target = random.choice(evens)
        instruction = f"Click the even number: {target}"
    elif challenge_type == 'greater':
        threshold = random.randint(8, 12)
        valid = [n for n in numbers if n > threshold]
        target = random.choice(valid) if valid else 13
        instruction = f"Click a number greater than {threshold}"
    else:
        threshold = random.randint(5, 8)
        valid = [n for n in numbers if n < threshold]
        target = random.choice(valid) if valid else 3
        instruction = f"Click a number less than {threshold}"
    
    challenge_id = generate_id("pow_")
    return PowChallenge(
        id=challenge_id,
        answer=target,
        instruction=instruction,
        numbers=numbers,
        expires_at=datetime.now() + timedelta(seconds=60)
    )


# ============================================
# Escrow System
# ============================================

def create_escrow(order: Order) -> Escrow:
    """Create escrow for an order"""
    escrow = Escrow(
        id=generate_id("esc_"),
        order_id=order.id,
        buyer_id=order.buyer_id,
        vendor_id=order.vendor_id,
        amount_xmr=order.total_xmr - order.fee_xmr,
        fee_xmr=order.fee_xmr,
        status=EscrowStatus.HELD,
        created_at=datetime.now()
    )
    escrows_store[escrow.id] = escrow
    return escrow


def release_escrow_to_vendor(escrow_id: str) -> bool:
    """Release escrow funds to vendor"""
    escrow = escrows_store.get(escrow_id)
    if not escrow or escrow.status != EscrowStatus.HELD:
        return False
    
    vendor = users_store.get(escrow.vendor_id)
    if vendor:
        vendor.balance_xmr += escrow.amount_xmr
        vendor.total_sales += 1
    
    escrow.status = EscrowStatus.RELEASED_TO_VENDOR
    escrow.released_at = datetime.now()
    return True


def refund_escrow_to_buyer(escrow_id: str) -> bool:
    """Refund escrow funds to buyer"""
    escrow = escrows_store.get(escrow_id)
    if not escrow or escrow.status != EscrowStatus.HELD:
        return False
    
    buyer = users_store.get(escrow.buyer_id)
    if buyer:
        buyer.balance_xmr += escrow.amount_xmr + escrow.fee_xmr
    
    escrow.status = EscrowStatus.REFUNDED_TO_BUYER
    escrow.released_at = datetime.now()
    return True


def split_escrow(escrow_id: str, buyer_percent: Decimal) -> bool:
    """Split escrow between buyer and vendor"""
    escrow = escrows_store.get(escrow_id)
    if not escrow or escrow.status != EscrowStatus.HELD:
        return False
    
    buyer_amount = (escrow.amount_xmr * buyer_percent / 100).quantize(Decimal("0.000001"))
    vendor_amount = escrow.amount_xmr - buyer_amount
    
    buyer = users_store.get(escrow.buyer_id)
    vendor = users_store.get(escrow.vendor_id)
    
    if buyer:
        buyer.balance_xmr += buyer_amount
    if vendor:
        vendor.balance_xmr += vendor_amount
    
    escrow.status = EscrowStatus.SPLIT
    escrow.released_at = datetime.now()
    return True


# ============================================
# Demo Data Initialization
# ============================================

def init_demo_data():
    """Initialize demo products and vendors"""
    products_store.clear()
    
    demo_products = [
        Product(
            id="prod_001",
            vendor_id="vendor_001",
            vendor_name="CryptoVault",
            title="Premium Security Suite",
            description="Complete digital security toolkit with encryption tools, secure communication protocols, and privacy-focused utilities. Includes lifetime updates.",
            price_xmr=Decimal("0.25"),
            category="Digital Goods",
            stock=999,
            rating=Decimal("4.8"),
            sales=127,
            shipping_options=["Digital Delivery"],
            created_at=datetime.now() - timedelta(days=30)
        ),
        Product(
            id="prod_002",
            vendor_id="vendor_002",
            vendor_name="GhostNet",
            title="Anonymous VPN Access - 12 Months",
            description="Premium VPN service with strict no-logs policy, multi-hop connections, dedicated IPs, and Tor over VPN support. Accepts XMR only.",
            price_xmr=Decimal("0.15"),
            category="Services",
            stock=50,
            rating=Decimal("4.9"),
            sales=89,
            shipping_options=["Digital Delivery"],
            created_at=datetime.now() - timedelta(days=45)
        ),
        Product(
            id="prod_003",
            vendor_id="vendor_001",
            vendor_name="CryptoVault",
            title="Secure Messaging Protocol License",
            description="Custom E2E encrypted messaging solution with forward secrecy, self-destructing messages, and decentralized architecture. Full source code included.",
            price_xmr=Decimal("0.50"),
            category="Software",
            stock=999,
            rating=Decimal("4.7"),
            sales=56,
            shipping_options=["Digital Delivery"],
            created_at=datetime.now() - timedelta(days=20)
        ),
        Product(
            id="prod_004",
            vendor_id="vendor_003",
            vendor_name="ShadowOps",
            title="Privacy Audit Service",
            description="Complete digital footprint analysis and cleanup. Our experts will identify and help remove your online traces. Includes detailed report.",
            price_xmr=Decimal("1.20"),
            category="Services",
            stock=10,
            rating=Decimal("5.0"),
            sales=34,
            shipping_options=["Consultation"],
            created_at=datetime.now() - timedelta(days=60)
        ),
        Product(
            id="prod_005",
            vendor_id="vendor_004",
            vendor_name="SecureHardware",
            title="Hardware Security Key Bundle (3x)",
            description="Set of 3 FIDO2/WebAuthn compatible security keys for ultimate account protection. Tamper-evident packaging. Ships worldwide.",
            price_xmr=Decimal("0.35"),
            category="Physical Goods",
            stock=25,
            rating=Decimal("4.6"),
            sales=78,
            shipping_options=["Worldwide Shipping", "Express Shipping"],
            created_at=datetime.now() - timedelta(days=15)
        ),
        Product(
            id="prod_006",
            vendor_id="vendor_004",
            vendor_name="SecureHardware",
            title="Encrypted Storage Drive 512GB",
            description="Hardware-encrypted USB drive with tamper-evident casing, dead-man switch, and secure erase functionality. Military-grade AES-256.",
            price_xmr=Decimal("0.80"),
            category="Physical Goods",
            stock=15,
            rating=Decimal("4.9"),
            sales=42,
            shipping_options=["Worldwide Shipping"],
            created_at=datetime.now() - timedelta(days=25)
        )
    ]
    
    for product in demo_products:
        products_store[product.id] = product


# ============================================
# Startup Event
# ============================================

@app.on_event("startup")
async def startup_event():
    init_server_keypair()
    init_demo_data()
    print("[ARCHITECT] Market initialized")
    print(f"[ARCHITECT] Server fingerprint: {SERVER_KEY_FINGERPRINT}")


# ============================================
# Template Context
# ============================================

def base_context(request: Request, **kwargs) -> dict:
    """Generate base template context"""
    user = get_current_user(request)
    return {
        "request": request,
        "user": user,
        "server_fingerprint": SERVER_KEY_FINGERPRINT,
        "current_year": datetime.now().year,
        **kwargs
    }


# ============================================
# Public Routes
# ============================================

@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    """Landing page"""
    user = get_current_user(request)
    if user:
        return RedirectResponse(url="/dashboard", status_code=303)
    return templates.TemplateResponse("home.html", base_context(request))


@app.get("/server-key", response_class=HTMLResponse)
async def server_key_page(request: Request):
    """Server public key page for verification"""
    return templates.TemplateResponse("server_key.html", base_context(
        request,
        server_public_key=get_server_public_key()
    ))


@app.get("/canary", response_class=HTMLResponse)
async def canary_page(request: Request):
    """Warrant canary page"""
    canary_message = f"""ARCHITECT Market Warrant Canary
================================
Date: {datetime.now().strftime("%Y-%m-%d %H:%M UTC")}

We have NOT received any:
- National Security Letters
- FISA court orders
- Gag orders of any type
- Subpoenas or court orders for user data
- Requests from law enforcement

This canary is updated every 72 hours.
If this message is not updated, assume compromise.
================================
"""
    signed_canary = sign_message(canary_message)
    
    return templates.TemplateResponse("canary.html", base_context(
        request,
        canary_message=signed_canary,
        last_updated=datetime.now().strftime("%Y-%m-%d %H:%M UTC")
    ))


# ============================================
# Proof of Work Routes
# ============================================

@app.get("/pow", response_class=HTMLResponse)
async def pow_page(request: Request):
    """Proof of work challenge page"""
    challenge = generate_pow_challenge()
    pow_challenges_store[challenge.id] = challenge
    
    return templates.TemplateResponse("pow_gate.html", base_context(
        request,
        challenge_id=challenge.id,
        numbers=challenge.numbers,
        instruction=challenge.instruction
    ))


@app.post("/pow/verify", response_class=HTMLResponse)
async def pow_verify(
    request: Request,
    challenge_id: str = Form(...),
    answer: str = Form(...)
):
    """Verify PoW challenge"""
    challenge = pow_challenges_store.get(challenge_id)
    
    if not challenge or datetime.now() > challenge.expires_at:
        return RedirectResponse(url="/pow?error=expired", status_code=303)
    
    try:
        submitted_answer = int(answer)
    except ValueError:
        return RedirectResponse(url="/pow?error=invalid", status_code=303)
    
    if submitted_answer == challenge.answer:
        bypass_token = secrets.token_urlsafe(32)
        pow_bypass_store[bypass_token] = datetime.now() + timedelta(hours=1)
        del pow_challenges_store[challenge_id]
        
        response = RedirectResponse(url="/", status_code=303)
        response.set_cookie(
            key="pow_bypass",
            value=bypass_token,
            max_age=3600,
            httponly=True,
            samesite="strict"
        )
        return response
    
    return RedirectResponse(url="/pow?error=wrong", status_code=303)


# ============================================
# Authentication Routes
# ============================================

@app.get("/auth/register", response_class=HTMLResponse)
async def register_page(request: Request):
    """Registration page"""
    return templates.TemplateResponse("auth/register.html", base_context(request))


@app.post("/auth/register", response_class=HTMLResponse)
async def register_step1(
    request: Request,
    username: str = Form(...),
    pgp_public_key: str = Form(...)
):
    """Process registration - generate challenge"""
    # Validate username format
    username = username.lower().strip()
    if not re.match(r'^[a-z0-9_]{3,20}$', username):
        return templates.TemplateResponse("auth/register.html", base_context(
            request,
            error="Invalid username. Use 3-20 lowercase letters, numbers, or underscores."
        ))
    
    # Check username uniqueness
    for user in users_store.values():
        if user.username == username:
            return templates.TemplateResponse("auth/register.html", base_context(
                request,
                error="Username already taken."
            ))
    
    # Validate PGP key format
    pgp_public_key = pgp_public_key.strip()
    if not pgp_public_key.startswith("-----BEGIN PGP PUBLIC KEY BLOCK-----"):
        return templates.TemplateResponse("auth/register.html", base_context(
            request,
            error="Invalid PGP public key format."
        ))
    
    # Import and validate PGP key
    user_fingerprint = import_user_key(pgp_public_key)
    if not user_fingerprint:
        return templates.TemplateResponse("auth/register.html", base_context(
            request,
            error="Could not import PGP key. Ensure it's a valid public key."
        ))
    
    # Check fingerprint uniqueness
    for user in users_store.values():
        if user.pgp_fingerprint == user_fingerprint:
            return templates.TemplateResponse("auth/register.html", base_context(
                request,
                error="This PGP key is already registered."
            ))
    
    # Generate ARCHITECT challenge
    architect_code = generate_architect_code()
    challenge_hash = hashlib.sha256(architect_code.encode()).hexdigest()
    
    challenges_store[username] = {
        "hash": challenge_hash,
        "expires": datetime.now() + timedelta(minutes=5)
    }
    
    pgp_store[username] = {
        "fingerprint": user_fingerprint,
        "public_key": pgp_public_key
    }
    
    # Create signed and encrypted challenge message
    challenge_message = f"""ARCHITECT Market Registration Challenge
========================================
Username: {username}
Challenge Code: {architect_code}
Timestamp: {datetime.now().isoformat()}
Server Fingerprint: {SERVER_KEY_FINGERPRINT}
========================================
Decrypt this message with your private key.
Paste the ARCHITECT code below to complete registration.
This challenge expires in 5 minutes.
"""
    
    encrypted_challenge = sign_and_encrypt(challenge_message, user_fingerprint)
    
    return templates.TemplateResponse("auth/register_challenge.html", base_context(
        request,
        username=username,
        encrypted_challenge=encrypted_challenge
    ))


@app.post("/auth/register/verify", response_class=HTMLResponse)
async def register_step2(
    request: Request,
    username: str = Form(...),
    architect_code: str = Form(...)
):
    """Verify registration challenge"""
    challenge = challenges_store.get(username)
    if not challenge or datetime.now() > challenge["expires"]:
        return templates.TemplateResponse("auth/register.html", base_context(
            request,
            error="Challenge expired. Please start registration again."
        ))
    
    # Verify ARCHITECT code
    architect_code = architect_code.strip()
    submitted_hash = hashlib.sha256(architect_code.encode()).hexdigest()
    
    if not secrets.compare_digest(submitted_hash, challenge["hash"]):
        return templates.TemplateResponse("auth/register_challenge.html", base_context(
            request,
            username=username,
            error="Invalid ARCHITECT code. Please try again.",
            encrypted_challenge="Challenge expired - please restart registration."
        ))
    
    # Get stored PGP data
    pgp_data = pgp_store.get(username)
    if not pgp_data:
        return templates.TemplateResponse("auth/register.html", base_context(
            request,
            error="Session expired. Please start registration again."
        ))
    
    # Create user
    user_id = generate_id("usr_")
    user = User(
        id=user_id,
        username=username,
        pgp_fingerprint=pgp_data["fingerprint"],
        pgp_public_key=pgp_data["public_key"],
        account_tier=AccountTier.BUYER,
        created_at=datetime.now(),
        anti_phishing_phrase=f"Your phrase: {secrets.token_hex(4)}"
    )
    users_store[user_id] = user
    
    # Clean up
    del challenges_store[username]
    del pgp_store[username]
    
    # Create session
    session_token = secrets.token_urlsafe(32)
    sessions_store[session_token] = user_id
    
    response = RedirectResponse(url="/dashboard", status_code=303)
    response.set_cookie(
        key="architect_session",
        value=session_token,
        max_age=1800,
        httponly=True,
        samesite="strict"
    )
    return response


@app.get("/auth/login", response_class=HTMLResponse)
async def login_page(request: Request):
    """Login page"""
    return templates.TemplateResponse("auth/login.html", base_context(request))


@app.post("/auth/login", response_class=HTMLResponse)
async def login_step1(
    request: Request,
    pgp_public_key: str = Form(...)
):
    """Process login - generate challenge"""
    pgp_public_key = pgp_public_key.strip()
    
    # Import and get fingerprint
    user_fingerprint = import_user_key(pgp_public_key)
    if not user_fingerprint:
        return templates.TemplateResponse("auth/login.html", base_context(
            request,
            error="Invalid PGP key."
        ))
    
    # Find user by fingerprint
    user = None
    for u in users_store.values():
        if u.pgp_fingerprint == user_fingerprint:
            user = u
            break
    
    if not user:
        return templates.TemplateResponse("auth/login.html", base_context(
            request,
            error="No account found with this PGP key."
        ))
    
    # Generate challenge
    architect_code = generate_architect_code()
    challenge_hash = hashlib.sha256(architect_code.encode()).hexdigest()
    
    challenges_store[user.username] = {
        "hash": challenge_hash,
        "expires": datetime.now() + timedelta(minutes=5)
    }
    
    # Create signed and encrypted challenge
    challenge_message = f"""ARCHITECT Market Login Challenge
========================================
Username: {user.username}
Challenge Code: {architect_code}
Timestamp: {datetime.now().isoformat()}
Server Fingerprint: {SERVER_KEY_FINGERPRINT}
Anti-Phishing: {user.anti_phishing_phrase}
========================================
Verify the anti-phishing phrase matches your settings.
Decrypt and paste the ARCHITECT code to login.
"""
    
    encrypted_challenge = sign_and_encrypt(challenge_message, user_fingerprint)
    
    return templates.TemplateResponse("auth/login_challenge.html", base_context(
        request,
        username=user.username,
        encrypted_challenge=encrypted_challenge
    ))


@app.post("/auth/login/verify", response_class=HTMLResponse)
async def login_step2(
    request: Request,
    username: str = Form(...),
    architect_code: str = Form(...)
):
    """Verify login challenge"""
    challenge = challenges_store.get(username)
    if not challenge or datetime.now() > challenge["expires"]:
        return templates.TemplateResponse("auth/login.html", base_context(
            request,
            error="Challenge expired. Please try again."
        ))
    
    # Verify code
    architect_code = architect_code.strip()
    submitted_hash = hashlib.sha256(architect_code.encode()).hexdigest()
    
    if not secrets.compare_digest(submitted_hash, challenge["hash"]):
        return templates.TemplateResponse("auth/login.html", base_context(
            request,
            error="Invalid ARCHITECT code."
        ))
    
    # Find user
    user = None
    for u in users_store.values():
        if u.username == username:
            user = u
            break
    
    if not user:
        return templates.TemplateResponse("auth/login.html", base_context(
            request,
            error="User not found."
        ))
    
    # Update last login
    user.last_login = datetime.now()
    
    # Clean up
    del challenges_store[username]
    
    # Create session
    session_token = secrets.token_urlsafe(32)
    sessions_store[session_token] = user.id
    
    response = RedirectResponse(url="/dashboard", status_code=303)
    response.set_cookie(
        key="architect_session",
        value=session_token,
        max_age=1800,
        httponly=True,
        samesite="strict"
    )
    return response


@app.get("/auth/logout")
async def logout(request: Request):
    """Logout and clear session"""
    session_token = request.cookies.get("architect_session")
    if session_token and session_token in sessions_store:
        del sessions_store[session_token]
    
    response = RedirectResponse(url="/", status_code=303)
    response.delete_cookie("architect_session")
    return response


# ============================================
# Dashboard Routes
# ============================================

@app.get("/dashboard", response_class=HTMLResponse)
async def dashboard(request: Request):
    """User dashboard"""
    user = get_current_user(request)
    if not user:
        return RedirectResponse(url="/auth/login", status_code=303)
    
    # Get user's orders
    user_orders = [o for o in orders_store.values() if o.buyer_id == user.id or o.vendor_id == user.id]
    recent_orders = sorted(user_orders, key=lambda x: x.created_at, reverse=True)[:5]
    
    # Get unread messages count
    unread_messages = sum(1 for m in messages_store.values() 
                         if m.recipient_id == user.id and not m.is_read)
    
    # Stats
    active_orders = sum(1 for o in user_orders if o.status in [
        OrderStatus.PAID, OrderStatus.PROCESSING, OrderStatus.SHIPPED
    ])
    
    return templates.TemplateResponse("dashboard.html", base_context(
        request,
        recent_orders=recent_orders,
        unread_messages=unread_messages,
        active_orders=active_orders,
        total_orders=len(user_orders)
    ))


# ============================================
# Marketplace Routes
# ============================================

@app.get("/marketplace", response_class=HTMLResponse)
async def marketplace(
    request: Request,
    category: Optional[str] = None,
    search: Optional[str] = None,
    sort: str = "newest"
):
    """Marketplace listing page"""
    user = get_current_user(request)
    if not user:
        return RedirectResponse(url="/auth/login", status_code=303)
    
    # Filter products
    products = [p for p in products_store.values() if p.is_active and p.stock > 0]
    
    if category:
        products = [p for p in products if p.category.lower() == category.lower()]
    
    if search:
        search_lower = search.lower()
        products = [p for p in products if 
                   search_lower in p.title.lower() or 
                   search_lower in p.description.lower()]
    
    # Sort
    if sort == "price_low":
        products.sort(key=lambda x: x.price_xmr)
    elif sort == "price_high":
        products.sort(key=lambda x: x.price_xmr, reverse=True)
    elif sort == "rating":
        products.sort(key=lambda x: x.rating, reverse=True)
    elif sort == "sales":
        products.sort(key=lambda x: x.sales, reverse=True)
    else:  # newest
        products.sort(key=lambda x: x.created_at, reverse=True)
    
    # Get categories
    categories = list(set(p.category for p in products_store.values()))
    
    return templates.TemplateResponse("marketplace.html", base_context(
        request,
        products=products,
        categories=categories,
        current_category=category,
        search_query=search,
        sort=sort
    ))


@app.get("/product/{product_id}", response_class=HTMLResponse)
async def product_detail(request: Request, product_id: str):
    """Product detail page"""
    user = get_current_user(request)
    if not user:
        return RedirectResponse(url="/auth/login", status_code=303)
    
    product = products_store.get(product_id)
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    
    return templates.TemplateResponse("product_detail.html", base_context(
        request,
        product=product
    ))


# ============================================
# Order Routes
# ============================================

@app.post("/order/create", response_class=HTMLResponse)
async def create_order(
    request: Request,
    product_id: str = Form(...),
    quantity: int = Form(1),
    shipping_option: str = Form(...),
    shipping_address: str = Form(...)
):
    """Create a new order"""
    user = get_current_user(request)
    if not user:
        return RedirectResponse(url="/auth/login", status_code=303)
    
    product = products_store.get(product_id)
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    
    if quantity > product.stock:
        raise HTTPException(status_code=400, detail="Insufficient stock")
    
    # Calculate totals
    subtotal = product.price_xmr * quantity
    fee = calculate_fee(subtotal)
    total = subtotal + fee
    
    # Encrypt shipping address with vendor's key (simulated)
    encrypted_address = f"[ENCRYPTED: {shipping_address[:20]}...]"
    
    # Create order
    order = Order(
        id=generate_id("ord_"),
        buyer_id=user.id,
        vendor_id=product.vendor_id,
        product_id=product_id,
        quantity=quantity,
        price_xmr=product.price_xmr,
        total_xmr=total,
        fee_xmr=fee,
        status=OrderStatus.PENDING_PAYMENT,
        shipping_address_encrypted=encrypted_address,
        shipping_option=shipping_option,
        created_at=datetime.now(),
        autofinalize_at=datetime.now() + timedelta(days=AUTOFINALIZE_DAYS)
    )
    orders_store[order.id] = order
    
    # Generate payment address
    address, payment_id = generate_xmr_address()
    
    deposit = Deposit(
        id=generate_id("dep_"),
        user_id=user.id,
        address=address,
        payment_id=payment_id,
        expected_amount=total,
        received_amount=Decimal("0"),
        purpose="order",
        reference_id=order.id,
        status=DepositStatus.PENDING,
        created_at=datetime.now(),
        expires_at=datetime.now() + timedelta(hours=DEPOSIT_EXPIRY_HOURS)
    )
    
    # Sign payment details
    payment_details = f"""ARCHITECT Market Order Payment
================================
Order ID: {order.id}
Product: {product.title}
Quantity: {quantity}
Amount: {format_xmr(total)} XMR
Address: {address}
Payment ID: {payment_id}
Expires: {deposit.expires_at.isoformat()}
Server: {SERVER_KEY_FINGERPRINT}
================================
"""
    deposit.signed_details = sign_message(payment_details)
    deposits_store[deposit.id] = deposit
    
    # Update product stock
    product.stock -= quantity
    
    return RedirectResponse(url=f"/order/{order.id}/pay", status_code=303)


@app.get("/order/{order_id}/pay", response_class=HTMLResponse)
async def order_payment(request: Request, order_id: str):
    """Order payment page"""
    user = get_current_user(request)
    if not user:
        return RedirectResponse(url="/auth/login", status_code=303)
    
    order = orders_store.get(order_id)
    if not order or order.buyer_id != user.id:
        raise HTTPException(status_code=404, detail="Order not found")
    
    # Find deposit
    deposit = None
    for d in deposits_store.values():
        if d.reference_id == order_id and d.purpose == "order":
            deposit = d
            break
    
    if not deposit:
        raise HTTPException(status_code=404, detail="Payment not found")
    
    product = products_store.get(order.product_id)
    qr_code = generate_qr_code_base64(f"monero:{deposit.address}?tx_amount={order.total_xmr}")
    
    return templates.TemplateResponse("order_payment.html", base_context(
        request,
        order=order,
        deposit=deposit,
        product=product,
        qr_code=qr_code,
        time_remaining=time_remaining(deposit.expires_at)
    ))


@app.get("/orders", response_class=HTMLResponse)
async def orders_list(request: Request):
    """User orders list"""
    user = get_current_user(request)
    if not user:
        return RedirectResponse(url="/auth/login", status_code=303)
    
    # Get user's orders (as buyer)
    orders = [o for o in orders_store.values() if o.buyer_id == user.id]
    orders.sort(key=lambda x: x.created_at, reverse=True)
    
    # Enrich with product info
    orders_with_products = []
    for order in orders:
        product = products_store.get(order.product_id)
        orders_with_products.append({
            "order": order,
            "product": product
        })
    
    return templates.TemplateResponse("orders.html", base_context(
        request,
        orders=orders_with_products
    ))


@app.get("/order/{order_id}", response_class=HTMLResponse)
async def order_detail(request: Request, order_id: str):
    """Order detail page"""
    user = get_current_user(request)
    if not user:
        return RedirectResponse(url="/auth/login", status_code=303)
    
    order = orders_store.get(order_id)
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    
    # Check access
    if order.buyer_id != user.id and order.vendor_id != user.id:
        raise HTTPException(status_code=403, detail="Access denied")
    
    product = products_store.get(order.product_id)
    
    # Find escrow
    escrow = None
    for e in escrows_store.values():
        if e.order_id == order_id:
            escrow = e
            break
    
    # Find dispute
    dispute = None
    for d in disputes_store.values():
        if d.order_id == order_id:
            dispute = d
            break
    
    return templates.TemplateResponse("order_detail.html", base_context(
        request,
        order=order,
        product=product,
        escrow=escrow,
        dispute=dispute,
        is_buyer=order.buyer_id == user.id,
        is_vendor=order.vendor_id == user.id
    ))


@app.post("/order/{order_id}/confirm-delivery", response_class=HTMLResponse)
async def confirm_delivery(request: Request, order_id: str):
    """Buyer confirms delivery - releases escrow"""
    user = get_current_user(request)
    if not user:
        return RedirectResponse(url="/auth/login", status_code=303)
    
    order = orders_store.get(order_id)
    if not order or order.buyer_id != user.id:
        raise HTTPException(status_code=404, detail="Order not found")
    
    if order.status not in [OrderStatus.SHIPPED, OrderStatus.DELIVERED]:
        raise HTTPException(status_code=400, detail="Cannot confirm delivery at this stage")
    
    # Find and release escrow
    for escrow in escrows_store.values():
        if escrow.order_id == order_id:
            release_escrow_to_vendor(escrow.id)
            break
    
    order.status = OrderStatus.COMPLETED
    order.completed_at = datetime.now()
    
    return RedirectResponse(url=f"/order/{order_id}", status_code=303)


@app.post("/order/{order_id}/dispute", response_class=HTMLResponse)
async def open_dispute(
    request: Request,
    order_id: str,
    reason: str = Form(...),
    evidence: str = Form(...)
):
    """Open a dispute on an order"""
    user = get_current_user(request)
    if not user:
        return RedirectResponse(url="/auth/login", status_code=303)
    
    order = orders_store.get(order_id)
    if not order or order.buyer_id != user.id:
        raise HTTPException(status_code=404, detail="Order not found")
    
    if order.status not in [OrderStatus.PAID, OrderStatus.SHIPPED, OrderStatus.DELIVERED]:
        raise HTTPException(status_code=400, detail="Cannot dispute at this stage")
    
    # Create dispute
    dispute = Dispute(
        id=generate_id("dsp_"),
        order_id=order_id,
        buyer_id=order.buyer_id,
        vendor_id=order.vendor_id,
        reason=reason,
        buyer_evidence=evidence,
        vendor_response="",
        admin_notes="",
        status=DisputeStatus.OPEN,
        created_at=datetime.now()
    )
    disputes_store[dispute.id] = dispute
    
    order.status = OrderStatus.DISPUTED
    
    return RedirectResponse(url=f"/order/{order_id}", status_code=303)


# ============================================
# Wallet Routes
# ============================================

@app.get("/wallet", response_class=HTMLResponse)
async def wallet(request: Request):
    """Wallet page"""
    user = get_current_user(request)
    if not user:
        return RedirectResponse(url="/auth/login", status_code=303)
    
    # Get user's deposits
    deposits = [d for d in deposits_store.values() if d.user_id == user.id]
    deposits.sort(key=lambda x: x.created_at, reverse=True)
    
    return templates.TemplateResponse("wallet.html", base_context(
        request,
        deposits=deposits[:10]
    ))


@app.get("/wallet/deposit", response_class=HTMLResponse)
async def wallet_deposit(request: Request):
    """Generate deposit address"""
    user = get_current_user(request)
    if not user:
        return RedirectResponse(url="/auth/login", status_code=303)
    
    # Generate new deposit address
    address, payment_id = generate_xmr_address()
    
    deposit = Deposit(
        id=generate_id("dep_"),
        user_id=user.id,
        address=address,
        payment_id=payment_id,
        expected_amount=Decimal("0"),
        received_amount=Decimal("0"),
        purpose="wallet",
        reference_id=None,
        status=DepositStatus.PENDING,
        created_at=datetime.now(),
        expires_at=datetime.now() + timedelta(hours=DEPOSIT_EXPIRY_HOURS)
    )
    
    # Sign deposit details
    details = f"""ARCHITECT Market Wallet Deposit
================================
Deposit ID: {deposit.id}
Address: {address}
Payment ID: {payment_id}
Expires: {deposit.expires_at.isoformat()}
Server: {SERVER_KEY_FINGERPRINT}
================================
"""
    deposit.signed_details = sign_message(details)
    deposits_store[deposit.id] = deposit
    
    qr_code = generate_qr_code_base64(f"monero:{address}")
    
    return templates.TemplateResponse("wallet_deposit.html", base_context(
        request,
        deposit=deposit,
        qr_code=qr_code,
        time_remaining=time_remaining(deposit.expires_at)
    ))


# ============================================
# Vendor Routes
# ============================================

@app.get("/vendor/upgrade", response_class=HTMLResponse)
async def vendor_upgrade(request: Request):
    """Vendor upgrade page"""
    user = get_current_user(request)
    if not user:
        return RedirectResponse(url="/auth/login", status_code=303)
    
    if user.account_tier == AccountTier.VENDOR:
        return RedirectResponse(url="/vendor/dashboard", status_code=303)
    
    fee_xmr = usd_to_xmr(VENDOR_UPGRADE_FEE_USD)
    
    return templates.TemplateResponse("vendor_upgrade.html", base_context(
        request,
        fee_usd=VENDOR_UPGRADE_FEE_USD,
        fee_xmr=fee_xmr
    ))


@app.post("/vendor/upgrade", response_class=HTMLResponse)
async def vendor_upgrade_apply(request: Request):
    """Start vendor upgrade payment"""
    user = get_current_user(request)
    if not user:
        return RedirectResponse(url="/auth/login", status_code=303)
    
    if user.account_tier == AccountTier.VENDOR:
        return RedirectResponse(url="/vendor/dashboard", status_code=303)
    
    fee_xmr = usd_to_xmr(VENDOR_UPGRADE_FEE_USD)
    address, payment_id = generate_xmr_address()
    
    deposit = Deposit(
        id=generate_id("dep_"),
        user_id=user.id,
        address=address,
        payment_id=payment_id,
        expected_amount=fee_xmr,
        received_amount=Decimal("0"),
        purpose="vendor_upgrade",
        reference_id=None,
        status=DepositStatus.PENDING,
        created_at=datetime.now(),
        expires_at=datetime.now() + timedelta(hours=DEPOSIT_EXPIRY_HOURS)
    )
    
    # Sign payment details
    details = f"""ARCHITECT Market Vendor Upgrade Payment
================================
Amount: {format_xmr(fee_xmr)} XMR (${VENDOR_UPGRADE_FEE_USD} USD)
Address: {address}
Payment ID: {payment_id}
Expires: {deposit.expires_at.isoformat()}
Server: {SERVER_KEY_FINGERPRINT}
================================
"""
    deposit.signed_details = sign_message(details)
    deposits_store[deposit.id] = deposit
    
    vendor_applications_store[user.id] = {
        "deposit_id": deposit.id,
        "status": "pending_payment",
        "created_at": datetime.now()
    }
    
    return RedirectResponse(url=f"/vendor/payment/{deposit.id}", status_code=303)


@app.get("/vendor/payment/{deposit_id}", response_class=HTMLResponse)
async def vendor_payment(request: Request, deposit_id: str):
    """Vendor upgrade payment page"""
    user = get_current_user(request)
    if not user:
        return RedirectResponse(url="/auth/login", status_code=303)
    
    deposit = deposits_store.get(deposit_id)
    if not deposit or deposit.user_id != user.id:
        raise HTTPException(status_code=404, detail="Payment not found")
    
    qr_code = generate_qr_code_base64(f"monero:{deposit.address}?tx_amount={deposit.expected_amount}")
    
    return templates.TemplateResponse("vendor_payment.html", base_context(
        request,
        deposit=deposit,
        qr_code=qr_code,
        time_remaining=time_remaining(deposit.expires_at)
    ))


@app.get("/vendor/dashboard", response_class=HTMLResponse)
async def vendor_dashboard(request: Request):
    """Vendor dashboard"""
    user = get_current_user(request)
    if not user:
        return RedirectResponse(url="/auth/login", status_code=303)
    
    if user.account_tier != AccountTier.VENDOR and user.account_tier != AccountTier.ADMIN:
        return RedirectResponse(url="/vendor/upgrade", status_code=303)
    
    # Get vendor's products
    products = [p for p in products_store.values() if p.vendor_id == user.id]
    
    # Get vendor's orders
    orders = [o for o in orders_store.values() if o.vendor_id == user.id]
    pending_orders = [o for o in orders if o.status in [OrderStatus.PAID, OrderStatus.PROCESSING]]
    
    return templates.TemplateResponse("vendor_dashboard.html", base_context(
        request,
        products=products,
        pending_orders=pending_orders,
        total_orders=len(orders),
        total_products=len(products)
    ))


# ============================================
# Messages Routes
# ============================================

@app.get("/messages", response_class=HTMLResponse)
async def messages_list(request: Request):
    """Messages inbox"""
    user = get_current_user(request)
    if not user:
        return RedirectResponse(url="/auth/login", status_code=303)
    
    # Get user's messages
    messages = [m for m in messages_store.values() if m.recipient_id == user.id]
    messages.sort(key=lambda x: x.created_at, reverse=True)
    
    return templates.TemplateResponse("messages.html", base_context(
        request,
        messages=messages
    ))


@app.get("/messages/compose", response_class=HTMLResponse)
async def messages_compose(request: Request, to: Optional[str] = None):
    """Compose new message"""
    user = get_current_user(request)
    if not user:
        return RedirectResponse(url="/auth/login", status_code=303)
    
    return templates.TemplateResponse("messages_compose.html", base_context(
        request,
        recipient=to
    ))


@app.post("/messages/send", response_class=HTMLResponse)
async def messages_send(
    request: Request,
    recipient: str = Form(...),
    subject: str = Form(...),
    content: str = Form(...)
):
    """Send a message"""
    user = get_current_user(request)
    if not user:
        return RedirectResponse(url="/auth/login", status_code=303)
    
    # Find recipient
    recipient_user = None
    for u in users_store.values():
        if u.username == recipient:
            recipient_user = u
            break
    
    if not recipient_user:
        return templates.TemplateResponse("messages_compose.html", base_context(
            request,
            error="Recipient not found"
        ))
    
    # Encrypt message content with recipient's PGP key
    encrypted_content = encrypt_for_user(content, recipient_user.pgp_fingerprint)
    
    message = Message(
        id=generate_id("msg_"),
        sender_id=user.id,
        recipient_id=recipient_user.id,
        subject=subject,
        content_encrypted=encrypted_content,
        is_read=False,
        created_at=datetime.now()
    )
    messages_store[message.id] = message
    
    return RedirectResponse(url="/messages", status_code=303)


# ============================================
# Settings Routes
# ============================================

@app.get("/settings", response_class=HTMLResponse)
async def settings(request: Request):
    """User settings page"""
    user = get_current_user(request)
    if not user:
        return RedirectResponse(url="/auth/login", status_code=303)
    
    return templates.TemplateResponse("settings.html", base_context(request))


@app.post("/settings/anti-phishing", response_class=HTMLResponse)
async def update_anti_phishing(
    request: Request,
    phrase: str = Form(...)
):
    """Update anti-phishing phrase"""
    user = get_current_user(request)
    if not user:
        return RedirectResponse(url="/auth/login", status_code=303)
    
    user.anti_phishing_phrase = phrase.strip()[:50]
    
    return RedirectResponse(url="/settings?updated=1", status_code=303)


@app.post("/settings/pgp", response_class=HTMLResponse)
async def update_pgp_key(
    request: Request,
    pgp_public_key: str = Form(...)
):
    """Update PGP public key"""
    user = get_current_user(request)
    if not user:
        return RedirectResponse(url="/auth/login", status_code=303)
    
    new_fingerprint = import_user_key(pgp_public_key)
    if not new_fingerprint:
        return templates.TemplateResponse("settings.html", base_context(
            request,
            error="Invalid PGP key"
        ))
    
    user.pgp_fingerprint = new_fingerprint
    user.pgp_public_key = pgp_public_key
    
    return RedirectResponse(url="/settings?updated=1", status_code=303)


# ============================================
# Simulate Payment (Demo Only)
# ============================================

@app.post("/demo/simulate-payment/{deposit_id}")
async def simulate_payment(request: Request, deposit_id: str):
    """Simulate a payment confirmation (demo only)"""
    user = get_current_user(request)
    if not user:
        return RedirectResponse(url="/auth/login", status_code=303)
    
    deposit = deposits_store.get(deposit_id)
    if not deposit or deposit.user_id != user.id:
        raise HTTPException(status_code=404, detail="Deposit not found")
    
    # Simulate payment confirmation
    deposit.status = DepositStatus.CONFIRMED
    deposit.received_amount = deposit.expected_amount
    deposit.confirmed_at = datetime.now()
    
    # Handle different purposes
    if deposit.purpose == "order" and deposit.reference_id:
        order = orders_store.get(deposit.reference_id)
        if order:
            order.status = OrderStatus.PAID
            order.paid_at = datetime.now()
            create_escrow(order)
    
    elif deposit.purpose == "vendor_upgrade":
        user.account_tier = AccountTier.VENDOR
        if user.id in vendor_applications_store:
            vendor_applications_store[user.id]["status"] = "approved"
    
    elif deposit.purpose == "wallet":
        user.balance_xmr += deposit.received_amount
    
    return RedirectResponse(url="/dashboard", status_code=303)


# ============================================
# Health Check
# ============================================

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "server_key": SERVER_KEY_FINGERPRINT[-16:] if SERVER_KEY_FINGERPRINT else None
    }
