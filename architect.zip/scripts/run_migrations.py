#!/usr/bin/env python3
"""
ARCHITECT Market Database Migration Runner
Executes SQL migrations in order with verbose logging
"""

import os
import sys
import glob
from datetime import datetime

try:
    import asyncio
    import asyncpg
    HAS_ASYNCPG = True
except ImportError:
    HAS_ASYNCPG = False
    asyncpg = None
    asyncio = None

# Configuration
DATABASE_URL = os.environ.get('DATABASE_URL', 'postgresql://architect:architect@localhost:5432/architect')


class MockMigrationRunner:
    """Mock migration runner for preview environment without asyncpg"""
    
    def __init__(self):
        self.migrations_table = 'schema_migrations'
        self.executed = set()
    
    def run(self, directory: str = None):
        """Simulate running migrations"""
        if directory is None:
            directory = os.path.dirname(os.path.abspath(__file__))
        
        print(f"[{datetime.now().strftime('%H:%M:%S')}] PREVIEW MODE: asyncpg not available")
        print(f"[{datetime.now().strftime('%H:%M:%S')}] Scanning for migration files...")
        
        # Get all SQL files
        pattern = os.path.join(directory, '*.sql')
        migration_files = sorted(glob.glob(pattern))
        
        if not migration_files:
            print(f"[{datetime.now().strftime('%H:%M:%S')}] No migration files found in {directory}")
            return
        
        print(f"[{datetime.now().strftime('%H:%M:%S')}] Found {len(migration_files)} migration file(s):")
        
        for filepath in migration_files:
            filename = os.path.basename(filepath)
            # Read and validate SQL
            try:
                with open(filepath, 'r') as f:
                    sql = f.read()
                
                # Basic SQL validation
                if 'CREATE TABLE' in sql or 'INSERT INTO' in sql or 'ALTER TABLE' in sql:
                    print(f"[{datetime.now().strftime('%H:%M:%S')}] VALIDATED: {filename} ({len(sql)} bytes)")
                else:
                    print(f"[{datetime.now().strftime('%H:%M:%S')}] WARNING: {filename} - no recognized SQL commands")
                    
            except Exception as e:
                print(f"[{datetime.now().strftime('%H:%M:%S')}] ERROR: {filename} - {e}")
        
        print(f"[{datetime.now().strftime('%H:%M:%S')}] ")
        print(f"[{datetime.now().strftime('%H:%M:%S')}] To run migrations on a real database:")
        print(f"[{datetime.now().strftime('%H:%M:%S')}]   1. Install asyncpg: pip install asyncpg")
        print(f"[{datetime.now().strftime('%H:%M:%S')}]   2. Set DATABASE_URL environment variable")
        print(f"[{datetime.now().strftime('%H:%M:%S')}]   3. Re-run this script")


class MigrationRunner:
    def __init__(self):
        self.conn = None
        self.migrations_table = 'schema_migrations'
    
    async def connect(self):
        """Connect to database"""
        print(f"[{datetime.now().strftime('%H:%M:%S')}] Connecting to database...")
        try:
            self.conn = await asyncpg.connect(DATABASE_URL)
            print(f"[{datetime.now().strftime('%H:%M:%S')}] Connected successfully")
        except Exception as e:
            print(f"[{datetime.now().strftime('%H:%M:%S')}] Connection failed: {e}")
            sys.exit(1)
    
    async def ensure_migrations_table(self):
        """Create migrations tracking table if not exists"""
        await self.conn.execute('''
            CREATE TABLE IF NOT EXISTS schema_migrations (
                id SERIAL PRIMARY KEY,
                filename VARCHAR(255) UNIQUE NOT NULL,
                executed_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
            )
        ''')
    
    async def get_executed_migrations(self):
        """Get list of already executed migrations"""
        rows = await self.conn.fetch(
            'SELECT filename FROM schema_migrations ORDER BY filename'
        )
        return {row['filename'] for row in rows}
    
    async def execute_migration(self, filepath: str):
        """Execute a single migration file"""
        filename = os.path.basename(filepath)
        print(f"[{datetime.now().strftime('%H:%M:%S')}] Executing: {filename}")
        
        try:
            with open(filepath, 'r') as f:
                sql = f.read()
            
            # Execute in transaction
            async with self.conn.transaction():
                await self.conn.execute(sql)
                await self.conn.execute(
                    'INSERT INTO schema_migrations (filename) VALUES ($1)',
                    filename
                )
            
            print(f"[{datetime.now().strftime('%H:%M:%S')}] SUCCESS: {filename}")
            return True
            
        except Exception as e:
            print(f"[{datetime.now().strftime('%H:%M:%S')}] FAILED: {filename}")
            print(f"    Error: {e}")
            return False
    
    async def run(self, directory: str = None):
        """Run all pending migrations"""
        if directory is None:
            directory = os.path.dirname(os.path.abspath(__file__))
        
        await self.connect()
        await self.ensure_migrations_table()
        
        # Get all SQL files
        pattern = os.path.join(directory, '*.sql')
        migration_files = sorted(glob.glob(pattern))
        
        if not migration_files:
            print(f"[{datetime.now().strftime('%H:%M:%S')}] No migration files found in {directory}")
            return
        
        print(f"[{datetime.now().strftime('%H:%M:%S')}] Found {len(migration_files)} migration file(s)")
        
        # Get executed migrations
        executed = await self.get_executed_migrations()
        
        # Run pending migrations
        pending = [f for f in migration_files if os.path.basename(f) not in executed]
        
        if not pending:
            print(f"[{datetime.now().strftime('%H:%M:%S')}] All migrations already executed")
            return
        
        print(f"[{datetime.now().strftime('%H:%M:%S')}] Running {len(pending)} pending migration(s)...")
        
        success_count = 0
        for filepath in pending:
            if await self.execute_migration(filepath):
                success_count += 1
            else:
                print(f"[{datetime.now().strftime('%H:%M:%S')}] Stopping due to migration failure")
                break
        
        print(f"[{datetime.now().strftime('%H:%M:%S')}] Completed: {success_count}/{len(pending)} migrations")
        
        await self.conn.close()


def main():
    print("=" * 60)
    print("ARCHITECT Market Database Migration Runner")
    print("=" * 60)
    
    # Check for specific directory argument
    directory = sys.argv[1] if len(sys.argv) > 1 else None
    
    if HAS_ASYNCPG:
        runner = MigrationRunner()
        asyncio.run(runner.run(directory))
    else:
        runner = MockMigrationRunner()
        runner.run(directory)


if __name__ == '__main__':
    main()
