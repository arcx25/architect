import { AppLayout } from "@/components/app-layout"

const conversations = [
  {
    id: 1,
    user: "ShadowDev",
    avatar: "S",
    lastMessage: "Your order has been shipped. Tracking...",
    time: "2h ago",
    unread: 2,
  },
  {
    id: 2,
    user: "CryptoVault",
    avatar: "C",
    lastMessage: "Thanks for your purchase! Let me know...",
    time: "5h ago",
    unread: 1,
  },
  {
    id: 3,
    user: "System",
    avatar: "A",
    lastMessage: "Your deposit of 0.5 XMR has been confirmed",
    time: "1d ago",
    unread: 0,
  },
  {
    id: 4,
    user: "GhostAcademy",
    avatar: "G",
    lastMessage: "Course access link enclosed in PGP message",
    time: "3d ago",
    unread: 0,
  },
]

export default function MessagesPage() {
  return (
    <AppLayout username="shadow_trader" tier="buyer">
      <div className="page-header">
        <h1 className="page-title">Messages</h1>
        <p className="page-subtitle">Encrypted conversations</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="glass-card lg:col-span-1 p-0 overflow-hidden">
          <div className="p-4 border-b border-[var(--glass-border)]">
            <input type="search" placeholder="Search conversations..." className="glass-input w-full" />
          </div>
          <div className="divide-y divide-[var(--glass-border)]">
            {conversations.map((conv) => (
              <button
                key={conv.id}
                className={`w-full p-4 flex items-start gap-3 hover:bg-[rgba(255,0,110,0.05)] transition-colors text-left ${
                  conv.id === 1 ? "bg-[rgba(255,0,110,0.1)]" : ""
                }`}
              >
                <div className="user-avatar shrink-0">{conv.avatar}</div>
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between items-center mb-1">
                    <span className="font-semibold">{conv.user}</span>
                    <span className="text-xs text-[var(--text-muted)]">{conv.time}</span>
                  </div>
                  <p className="text-sm text-[var(--text-muted)] truncate">{conv.lastMessage}</p>
                </div>
                {conv.unread > 0 && <span className="badge">{conv.unread}</span>}
              </button>
            ))}
          </div>
        </div>

        <div className="glass-card lg:col-span-2 flex flex-col">
          <div className="flex items-center gap-3 pb-4 border-b border-[var(--glass-border)]">
            <div className="user-avatar">S</div>
            <div>
              <div className="font-semibold">ShadowDev</div>
              <div className="text-xs text-[var(--text-muted)]">Verified Vendor</div>
            </div>
          </div>

          <div className="flex-1 py-6 space-y-4 min-h-[400px]">
            <div className="flex gap-3">
              <div className="user-avatar shrink-0">S</div>
              <div className="glass-card-dark max-w-[80%]">
                <p className="text-sm">Your order has been shipped. Here is the encrypted tracking information:</p>
                <pre className="pgp-message mt-2 text-xs">
                  {`-----BEGIN PGP MESSAGE-----
hQIMA9Z3/6Gx8jK2...
-----END PGP MESSAGE-----`}
                </pre>
              </div>
            </div>

            <div className="flex gap-3 justify-end">
              <div className="glass-card max-w-[80%] bg-[rgba(255,0,110,0.1)]">
                <p className="text-sm">Thanks! I&apos;ll decrypt that now. Appreciate the fast shipping.</p>
              </div>
              <div className="user-avatar shrink-0">Y</div>
            </div>
          </div>

          <div className="pt-4 border-t border-[var(--glass-border)]">
            <div className="flex gap-3">
              <textarea
                rows={3}
                placeholder="Type your encrypted message..."
                className="glass-input flex-1 resize-none"
              />
              <button className="btn-primary btn-glow self-end">Send</button>
            </div>
            <p className="text-xs text-[var(--text-muted)] mt-2">All messages are PGP encrypted end-to-end</p>
          </div>
        </div>
      </div>
    </AppLayout>
  )
}
