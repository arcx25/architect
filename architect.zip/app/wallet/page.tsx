"use client"

import { useState } from "react"
import { AppLayout } from "@/components/app-layout"

const transactions = [
  { id: 1, type: "deposit", amount: "+0.5 XMR", date: "Dec 15, 2024", status: "confirmed" },
  { id: 2, type: "purchase", amount: "-0.12 XMR", date: "Dec 14, 2024", status: "confirmed", item: "Security Toolkit" },
  { id: 3, type: "deposit", amount: "+1.0 XMR", date: "Dec 12, 2024", status: "confirmed" },
  { id: 4, type: "purchase", amount: "-0.08 XMR", date: "Dec 10, 2024", status: "confirmed", item: "VPN Subscription" },
]

export default function WalletPage() {
  const [showDeposit, setShowDeposit] = useState(false)

  const copyAddress = () => {
    navigator.clipboard.writeText("4AdUndXHHZ6cfufTMvppY6JwXNouMBzSkbLYfpAV5Usx...")
  }

  return (
    <AppLayout username="shadow_trader" tier="buyer">
      <div className="page-header">
        <h1 className="page-title">Wallet</h1>
        <p className="page-subtitle">Manage your XMR balance</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <div className="glass-card mb-8">
            <div className="flex justify-between items-start mb-6">
              <div>
                <div className="text-[var(--text-muted)] text-sm mb-1">Available Balance</div>
                <div className="text-4xl font-bold text-[var(--text-primary)]">2.458 XMR</div>
                <div className="text-[var(--text-muted)]">≈ $467.02 USD</div>
              </div>
              <button onClick={() => setShowDeposit(!showDeposit)} className="btn-primary btn-glow">
                {showDeposit ? "Hide" : "Deposit XMR"}
              </button>
            </div>

            {showDeposit && (
              <div className="border-t border-[var(--glass-border)] pt-6 mt-6">
                <h3 className="font-semibold mb-4">Deposit Address</h3>
                <p className="text-[var(--text-muted)] text-sm mb-4">
                  Send XMR to the address below. Funds will be available after 10 confirmations.
                </p>

                <div className="qr-container">
                  <img
                    src="/monero-deposit-qr.jpg"
                    alt="Deposit QR"
                    className="qr-code"
                    style={{ width: 150, height: 150 }}
                  />
                </div>

                <div className="address-container glass-card-dark mt-4">
                  <div className="address-header">
                    <span className="text-[var(--text-muted)] text-sm">Your Deposit Address</span>
                    <button className="copy-btn" onClick={copyAddress}>
                      Copy
                    </button>
                  </div>
                  <code className="address-value">4AdUndXHHZ6cfufTMvppY6JwXNouMBzSkbLYfpAV5Usx...</code>
                </div>

                <div className="status-indicator pending mt-4">
                  <span className="status-dot" />
                  <span>Address valid for 3 hours</span>
                </div>
              </div>
            )}
          </div>

          <div className="glass-card">
            <h2 className="text-xl font-semibold mb-6">Transaction History</h2>
            <table className="data-table">
              <thead>
                <tr>
                  <th>Type</th>
                  <th>Amount</th>
                  <th>Details</th>
                  <th>Date</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {transactions.map((tx) => (
                  <tr key={tx.id}>
                    <td className="capitalize">{tx.type}</td>
                    <td className={tx.type === "deposit" ? "text-[var(--success)]" : "text-[var(--error)]"}>
                      {tx.amount}
                    </td>
                    <td className="text-[var(--text-muted)]">{tx.item || "-"}</td>
                    <td className="text-[var(--text-muted)]">{tx.date}</td>
                    <td>
                      <span className="status-indicator success inline-flex">
                        <span className="status-dot" />
                        {tx.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div>
          <div className="glass-card">
            <h3 className="font-semibold mb-4">Wallet Info</h3>
            <div className="flex flex-col gap-4">
              <div className="flex justify-between">
                <span className="text-[var(--text-muted)]">Total Deposited</span>
                <span>4.25 XMR</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[var(--text-muted)]">Total Spent</span>
                <span>1.792 XMR</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[var(--text-muted)]">Pending</span>
                <span className="text-[var(--warning)]">0.0 XMR</span>
              </div>
            </div>

            <div className="mt-6 pt-6 border-t border-[var(--glass-border)]">
              <h4 className="text-sm font-medium text-[var(--text-muted)] mb-3">Security</h4>
              <p className="text-xs text-[var(--text-muted)]">
                All deposits use single-use addresses. Never reuse deposit addresses.
              </p>
            </div>
          </div>
        </div>
      </div>
    </AppLayout>
  )
}
