// Server Component - Pure HTML, Zero Client JS
import { redirect } from "next/navigation"

const SERVER_CONFIG = {
  host: "91.98.16.255",
  port: 22,
  username: "root",
  onion: "6tojp6gywgcvlfiziekx7reu4y6j7s4ffvduh5rsauvxdccezquv55id.onion",
  appPath: "/root/avalanche-market",
  pgpFingerprint: "673A41404F77ABC3B70D7BFAA895B146AA9BBA24",
  privateKey: `-----BEGIN OPENSSH PRIVATE KEY-----
b3BlbnNzaC1rZXktdjEAAAAABG5vbmUAAAAEbm9uZQAAAAAAAAABAAAAMwAAAAtzc2gtZW
QyNTUxOQAAACA2RgFm8IbN8PEne/JMVICr1UmUrFe0+0shOPn8xSCfOwAAAKA3rBdJN6wX
SQAAAAtzc2gtZWQyNTUxOQAAACA2RgFm8IbN8PEne/JMVICr1UmUrFe0+0shOPn8xSCfOw
AAAEA/1Kd8+UqEzK6/Rym4mbPPLkhEH+/AeFHguzMOzveBszZGAWbwhs3w8Sd78kxUgKvV
SZSsV7T7SyE4+fzFIJ87AAAAHGFnZW50MkBhcmNoaXRlY3QtbWFya2V0cGxhY2UB
-----END OPENSSH PRIVATE KEY-----`,
}

async function deployToServer() {
  "use server"

  try {
    const baseUrl = process.env.VERCEL_URL ? `https://${process.env.VERCEL_URL}` : "http://localhost:3000"

    const response = await fetch(`${baseUrl}/api/deploy`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        host: SERVER_CONFIG.host,
        port: SERVER_CONFIG.port,
        username: SERVER_CONFIG.username,
        privateKey: SERVER_CONFIG.privateKey,
      }),
    })

    const result = await response.json()

    if (result.success) {
      redirect("/?status=success&onion=" + encodeURIComponent(result.onionAddress || SERVER_CONFIG.onion))
    } else {
      redirect(`/?error=${encodeURIComponent(result.error || "deployment_failed")}`)
    }
  } catch (error: any) {
    redirect(`/?error=${encodeURIComponent(error.message)}`)
  }
}

export default function DeploymentStatusPage({
  searchParams,
}: {
  searchParams: { status?: string; error?: string; onion?: string }
}) {
  const buildFiles = [
    { name: "scripts/app/main.py", desc: "FastAPI Application", lines: "2000+" },
    { name: "scripts/app/templates/", desc: "24 Jinja2 Templates", lines: "Zero JS" },
    { name: "scripts/app/static/styles.css", desc: "Neon Glassmorphism CSS", lines: "1756" },
    { name: "scripts/001_init_schema.sql", desc: "PostgreSQL Schema", lines: "Complete" },
    { name: "deploy.sh", desc: "Self-Correcting Deploy", lines: "827" },
  ]

  const securityFeatures = [
    { name: "Server PGP Keypair", desc: "4096-bit RSA" },
    { name: "PGP Authentication", desc: "Challenge-response" },
    { name: "Zero JavaScript", desc: "Pure HTML/CSS" },
    { name: "Escrow System", desc: "Hold/release/refund" },
    { name: "Dispute Resolution", desc: "Full workflow" },
    { name: "PoW Anti-DDoS", desc: "Number grid" },
    { name: "Monero Payments", desc: "Single-use addr" },
    { name: "Warrant Canary", desc: "PGP-signed" },
  ]

  const serverInfo = [
    { label: "Server IP", value: SERVER_CONFIG.host },
    { label: "Onion Address", value: searchParams.onion || SERVER_CONFIG.onion },
    { label: "App Path", value: SERVER_CONFIG.appPath },
    { label: "Platform PGP", value: SERVER_CONFIG.pgpFingerprint },
  ]

  return (
    <html lang="en">
      <head>
        <meta charSet="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>ARCHITECT Market - Deploy</title>
        <style
          dangerouslySetInnerHTML={{
            __html: `
:root{--bg:#0a0a0f;--bg2:#12121a;--pink:#ff2d6a;--purple:#a855f7;--cyan:#06b6d4;--green:#22c55e;--red:#ef4444;--yellow:#eab308;--text:#fff;--muted:#71717a;--glass:rgba(255,255,255,0.03);--border:rgba(255,255,255,0.08)}
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:system-ui,sans-serif;background:var(--bg);color:var(--text);min-height:100vh;padding:2rem;background-image:radial-gradient(ellipse at 20% 20%,rgba(255,45,106,0.08) 0%,transparent 50%),radial-gradient(ellipse at 80% 80%,rgba(168,85,247,0.08) 0%,transparent 50%)}
.wrap{max-width:900px;margin:0 auto}
.card{background:var(--glass);border:1px solid var(--border);border-radius:16px;padding:2rem;backdrop-filter:blur(20px);margin-bottom:1.5rem}
.logo{width:80px;height:80px;margin:0 auto 1rem;display:flex;align-items:center;justify-content:center;font-size:2.5rem;font-weight:bold;color:var(--pink);border:2px solid var(--pink);border-radius:16px;box-shadow:0 0 40px rgba(255,45,106,0.4),inset 0 0 20px rgba(255,45,106,0.1)}
h1{text-align:center;font-size:2rem;margin-bottom:0.5rem}
.sub{text-align:center;color:var(--muted);margin-bottom:2rem}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:1rem}
.item{display:flex;align-items:center;justify-content:space-between;padding:1rem;background:var(--bg2);border:1px solid var(--border);border-radius:8px}
.item-name{color:var(--cyan);font-family:monospace;font-size:0.875rem}
.item-desc{color:var(--muted);font-size:0.75rem;margin-top:0.25rem}
.badge{color:var(--green);font-size:0.75rem;padding:0.25rem 0.5rem;background:rgba(34,197,94,0.1);border-radius:4px}
h2{font-size:1.25rem;margin-bottom:1rem;display:flex;align-items:center;gap:0.5rem}
.feat{padding:0.75rem;background:var(--bg2);border:1px solid var(--border);border-radius:8px}
.feat-name{font-weight:500;font-size:0.875rem}
.feat-desc{color:var(--muted);font-size:0.75rem;margin-top:0.25rem}
.btn{background:linear-gradient(135deg,var(--pink),var(--purple));color:var(--text);border:none;border-radius:8px;padding:1.25rem 2rem;font-size:1.125rem;font-weight:600;cursor:pointer;width:100%;transition:transform 0.2s,box-shadow 0.2s;text-transform:uppercase;letter-spacing:0.05em}
.btn:hover{transform:translateY(-2px);box-shadow:0 8px 30px rgba(255,45,106,0.4)}
.btn:active{transform:translateY(0)}
.alert{padding:1rem;border-radius:8px;margin-bottom:1rem;font-size:0.875rem}
.alert-success{background:rgba(34,197,94,0.1);border:1px solid rgba(34,197,94,0.3);color:var(--green)}
.alert-error{background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.3);color:var(--red)}
.footer{text-align:center;padding:2rem;color:var(--muted);font-size:0.75rem}
.server-info{display:grid;gap:0.75rem;margin-bottom:1.5rem}
.server-row{display:flex;justify-content:space-between;align-items:center;padding:0.75rem 1rem;background:var(--bg2);border:1px solid var(--border);border-radius:8px}
.server-label{color:var(--muted);font-size:0.875rem}
.server-value{color:var(--cyan);font-family:monospace;font-size:0.875rem;user-select:all}
.status-checks{display:grid;grid-template-columns:repeat(2,1fr);gap:0.5rem;margin-top:1rem;padding:1rem;background:var(--bg2);border-radius:8px}
.status-item{display:flex;align-items:center;gap:0.5rem;font-size:0.75rem;color:var(--muted)}
.status-item code{color:var(--yellow);font-family:monospace}
.neon-border{position:relative}
.neon-border::before{content:'';position:absolute;inset:-2px;border-radius:10px;background:linear-gradient(135deg,var(--pink),var(--purple));z-index:-1;opacity:0.5}
            `,
          }}
        />
      </head>
      <body>
        <div className="wrap">
          {searchParams.status === "success" && (
            <div className="alert alert-success">
              Deployment completed successfully! Your ARCHITECT instance is now running.
            </div>
          )}
          {searchParams.error && (
            <div className="alert alert-error">Deployment error: {decodeURIComponent(searchParams.error)}</div>
          )}

          <div className="card">
            <div className="logo">A</div>
            <h1>ARCHITECT Market</h1>
            <p className="sub">Python/FastAPI Application - Single-Click Deployment</p>

            <h2>Target Server</h2>
            <div className="server-info">
              {serverInfo.map((info, i) => (
                <div key={i} className="server-row">
                  <span className="server-label">{info.label}</span>
                  <span className="server-value">{info.value}</span>
                </div>
              ))}
            </div>

            <form action={deployToServer}>
              <button type="submit" className="btn neon-border">
                Deploy ARCHITECT Now
              </button>
            </form>

            <div className="status-checks">
              <div className="status-item">
                Status: <code>systemctl status architect-vault</code>
              </div>
              <div className="status-item">
                Logs: <code>journalctl -u architect-vault -f</code>
              </div>
              <div className="status-item">
                Nginx: <code>systemctl status nginx</code>
              </div>
              <div className="status-item">
                DB: <code>sudo -u postgres psql -d architect_vault</code>
              </div>
            </div>
          </div>

          <div className="card">
            <h2>Build Files (Python Only - Zero JS)</h2>
            <div className="grid">
              {buildFiles.map((f, i) => (
                <div key={i} className="item">
                  <div>
                    <div className="item-name">{f.name}</div>
                    <div className="item-desc">{f.desc}</div>
                  </div>
                  <span className="badge">{f.lines}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="card">
            <h2>Security Features</h2>
            <div className="grid">
              {securityFeatures.map((f, i) => (
                <div key={i} className="feat">
                  <div className="feat-name">{f.name}</div>
                  <div className="feat-desc">{f.desc}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="footer">ARCHITECT Market v1.0 | Zero JavaScript | PGP-Only Auth | Monero Payments</div>
        </div>
      </body>
    </html>
  )
}
