"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { Logo } from "@/components/logo"

type Step = "input" | "challenge"

export default function RegisterPage() {
  const [step, setStep] = useState<Step>("input")
  const [username, setUsername] = useState("")
  const [pgpKey, setPgpKey] = useState("")
  const [encryptedChallenge, setEncryptedChallenge] = useState("")
  const [architectCode, setArchitectCode] = useState("")
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(false)

  const handleSubmitKey = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError("")

    // Simulate server response with encrypted challenge
    await new Promise((r) => setTimeout(r, 1000))

    // In production, this would be an actual PGP-encrypted message
    const mockChallenge = `-----BEGIN PGP MESSAGE-----

hQIMA9Z3/6Gx8jK2ARAAlK8tVq7RmHJNx...
(Your ARCHITECT challenge is encrypted here)
...
-----END PGP MESSAGE-----`

    setEncryptedChallenge(mockChallenge)
    setStep("challenge")
    setLoading(false)
  }

  const handleVerifyChallenge = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError("")

    // Validate ARCHITECT code format
    if (!architectCode.match(/^ARCHITECT_[A-Za-z0-9_-]{20,80}$/)) {
      setError("Invalid ARCHITECT code format")
      setLoading(false)
      return
    }

    // In production, verify against server
    await new Promise((r) => setTimeout(r, 1000))

    // Redirect to dashboard on success
    window.location.href = "/dashboard"
  }

  const copyToClipboard = () => {
    navigator.clipboard.writeText(encryptedChallenge)
  }

  if (step === "challenge") {
    return (
      <div className="auth-page">
        <div className="glass-card auth-card">
          <div className="flex justify-center mb-8">
            <Logo />
          </div>

          <h2 className="text-2xl font-bold mb-2">Decrypt Challenge</h2>
          <p className="text-[var(--text-secondary)] mb-6">
            Copy the PGP message below, decrypt it locally, and paste the ARCHITECT code.
          </p>

          <div className="pgp-container glass-card-dark">
            <div className="pgp-header">
              <span className="pgp-label">Encrypted Challenge</span>
              <button type="button" className="copy-btn" onClick={copyToClipboard}>
                Copy
              </button>
            </div>
            <pre className="pgp-message">{encryptedChallenge}</pre>
          </div>

          <form onSubmit={handleVerifyChallenge} className="auth-form">
            <div className="form-group">
              <label>Decrypted ARCHITECT Code</label>
              <input
                type="text"
                value={architectCode}
                onChange={(e) => setArchitectCode(e.target.value)}
                placeholder="ARCHITECT_k8jN2pQ9xLm..."
                className="glass-input mono"
                required
              />
              <small className="form-hint">
                Format: ARCHITECT_{"{"}64 random characters{"}"}
              </small>
            </div>

            {error && (
              <div className="status-indicator error mb-4">
                <span className="status-dot" />
                {error}
              </div>
            )}

            <button type="submit" className="btn-primary btn-glow w-full" disabled={loading}>
              {loading ? "Verifying..." : "Complete Registration"}
            </button>
          </form>

          <button type="button" className="btn-secondary w-full mt-4" onClick={() => setStep("input")}>
            Back
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="auth-page">
      <div className="glass-card auth-card">
        <div className="flex justify-center mb-8">
          <Logo />
        </div>

        <h1>Create Account</h1>
        <p className="subtitle">Zero-knowledge registration via PGP</p>

        <form onSubmit={handleSubmitKey} className="auth-form">
          <div className="form-group">
            <label>Username</label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value.toLowerCase())}
              pattern="^[a-z0-9_]{3,20}$"
              placeholder="3-20 characters (a-z, 0-9, _)"
              className="glass-input"
              required
            />
          </div>

          <div className="form-group">
            <label>PGP Public Key</label>
            <textarea
              value={pgpKey}
              onChange={(e) => setPgpKey(e.target.value)}
              rows={12}
              placeholder={`-----BEGIN PGP PUBLIC KEY BLOCK-----

...your key here...

-----END PGP PUBLIC KEY BLOCK-----`}
              className="glass-input mono"
              required
            />
          </div>

          {error && (
            <div className="status-indicator error mb-4">
              <span className="status-dot" />
              {error}
            </div>
          )}

          <button type="submit" className="btn-primary btn-glow w-full" disabled={loading}>
            {loading ? "Processing..." : "Generate Challenge"}
          </button>
        </form>

        <p className="text-center mt-6 text-[var(--text-muted)]">
          Already have an account?{" "}
          <Link href="/auth/login" className="text-[var(--neon-pink)] hover:underline">
            Login
          </Link>
        </p>
      </div>
    </div>
  )
}
