"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { Logo } from "@/components/logo"

type Step = "input" | "challenge"

export default function LoginPage() {
  const [step, setStep] = useState<Step>("input")
  const [pgpKey, setPgpKey] = useState("")
  const [encryptedChallenge, setEncryptedChallenge] = useState("")
  const [architectCode, setArchitectCode] = useState("")
  const [username, setUsername] = useState("")
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(false)

  const handleSubmitKey = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError("")

    // Simulate server lookup and challenge generation
    await new Promise((r) => setTimeout(r, 1000))

    // In production, server would find user by fingerprint
    const mockChallenge = `-----BEGIN PGP MESSAGE-----

hQIMA9Z3/6Gx8jK2ARAAlK8tVq7RmHJNx...
(Your login ARCHITECT challenge is encrypted here)
...
-----END PGP MESSAGE-----`

    setEncryptedChallenge(mockChallenge)
    setUsername("found_user") // Would come from server
    setStep("challenge")
    setLoading(false)
  }

  const handleVerifyChallenge = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError("")

    if (!architectCode.match(/^ARCHITECT_[A-Za-z0-9_-]{20,80}$/)) {
      setError("Invalid ARCHITECT code format")
      setLoading(false)
      return
    }

    await new Promise((r) => setTimeout(r, 1000))
    window.location.href = "/dashboard"
  }

  const copyToClipboard = () => {
    navigator.clipboard.writeText(encryptedChallenge)
  }

  if (step === "challenge") {
    return (
      <div className="auth-page">
        <div className="glass-card auth-card">
          <div className="flex justify-center mb-8">
            <Logo />
          </div>

          <h2 className="text-2xl font-bold mb-2">Decrypt Challenge</h2>
          <p className="text-[var(--text-secondary)] mb-2">
            Welcome back, <span className="text-[var(--accent-cyan)]">{username}</span>
          </p>
          <p className="text-[var(--text-muted)] mb-6 text-sm">Decrypt the message and paste your ARCHITECT code.</p>

          <div className="pgp-container glass-card-dark">
            <div className="pgp-header">
              <span className="pgp-label">Encrypted Challenge</span>
              <button type="button" className="copy-btn" onClick={copyToClipboard}>
                Copy
              </button>
            </div>
            <pre className="pgp-message">{encryptedChallenge}</pre>
          </div>

          <form onSubmit={handleVerifyChallenge} className="auth-form">
            <div className="form-group">
              <label>Decrypted ARCHITECT Code</label>
              <input
                type="text"
                value={architectCode}
                onChange={(e) => setArchitectCode(e.target.value)}
                placeholder="ARCHITECT_k8jN2pQ9xLm..."
                className="glass-input mono"
                required
              />
            </div>

            {error && (
              <div className="status-indicator error mb-4">
                <span className="status-dot" />
                {error}
              </div>
            )}

            <button type="submit" className="btn-primary btn-glow w-full" disabled={loading}>
              {loading ? "Authenticating..." : "Login"}
            </button>
          </form>

          <button type="button" className="btn-secondary w-full mt-4" onClick={() => setStep("input")}>
            Back
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="auth-page">
      <div className="glass-card auth-card">
        <div className="flex justify-center mb-8">
          <Logo />
        </div>

        <h1>Login</h1>
        <p className="subtitle">Authenticate with your PGP key</p>

        <form onSubmit={handleSubmitKey} className="auth-form">
          <div className="form-group">
            <label>PGP Public Key</label>
            <textarea
              value={pgpKey}
              onChange={(e) => setPgpKey(e.target.value)}
              rows={12}
              placeholder={`-----BEGIN PGP PUBLIC KEY BLOCK-----

...paste your registered key...

-----END PGP PUBLIC KEY BLOCK-----`}
              className="glass-input mono"
              required
            />
          </div>

          {error && (
            <div className="status-indicator error mb-4">
              <span className="status-dot" />
              {error}
            </div>
          )}

          <button type="submit" className="btn-primary btn-glow w-full" disabled={loading}>
            {loading ? "Looking up key..." : "Generate Challenge"}
          </button>
        </form>

        <p className="text-center mt-6 text-[var(--text-muted)]">
          Need an account?{" "}
          <Link href="/auth/register" className="text-[var(--neon-pink)] hover:underline">
            Register
          </Link>
        </p>
      </div>
    </div>
  )
}
