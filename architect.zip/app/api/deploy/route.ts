import { NextResponse } from "next/server"
import { readFile } from "fs/promises"
import { join } from "path"

interface DeployLog {
  timestamp: string
  level: "info" | "success" | "error" | "warn"
  message: string
}

function log(logs: DeployLog[], level: DeployLog["level"], message: string) {
  logs.push({ timestamp: new Date().toISOString(), level, message })
  console.log(`[v0] [${level.toUpperCase()}] ${message}`)
}

const DEPLOY_FILES = [
  { local: "scripts/app/main.py", remote: "/root/avalanche-market/app/main.py" },
  { local: "scripts/app/static/styles.css", remote: "/root/avalanche-market/app/static/styles.css" },
  { local: "scripts/001_init_schema.sql", remote: "/root/avalanche-market/scripts/001_init_schema.sql" },
  { local: "scripts/002_seed_demo_data.sql", remote: "/root/avalanche-market/scripts/002_seed_demo_data.sql" },
  { local: "requirements.txt", remote: "/root/avalanche-market/requirements.txt" },
  { local: "deploy.sh", remote: "/root/avalanche-market/deploy.sh" },
]

const TEMPLATE_FILES = [
  "base.html",
  "layout.html",
  "home.html",
  "dashboard.html",
  "marketplace.html",
  "product_detail.html",
  "orders.html",
  "order_detail.html",
  "order_payment.html",
  "wallet.html",
  "wallet_deposit.html",
  "messages.html",
  "messages_compose.html",
  "vendor_upgrade.html",
  "vendor_payment.html",
  "vendor_dashboard.html",
  "settings.html",
  "server_key.html",
  "canary.html",
  "pow_gate.html",
  "auth/register.html",
  "auth/register_challenge.html",
  "auth/login.html",
  "auth/login_challenge.html",
]

export async function POST(request: Request) {
  const logs: DeployLog[] = []
  let conn: any = null

  try {
    const { host, port = 22, username, password, privateKey } = await request.json()

    if (!host || !username) {
      return NextResponse.json({ success: false, error: "Missing host or username", logs }, { status: 400 })
    }

    if (!password && !privateKey) {
      return NextResponse.json({ success: false, error: "Missing password or privateKey", logs }, { status: 400 })
    }

    log(logs, "info", `Starting deployment to ${username}@${host}:${port}`)

    // Dynamic import of ssh2
    let Client: any
    try {
      const ssh2 = await import("ssh2")
      Client = ssh2.Client
      log(logs, "success", "SSH2 module loaded")
    } catch (e) {
      log(logs, "error", "SSH2 module not available")
      return NextResponse.json(
        {
          success: false,
          error: "SSH2 not available in this environment",
          logs,
        },
        { status: 500 },
      )
    }

    conn = new Client()

    // Connect to server
    log(logs, "info", "Establishing SSH connection...")
    await new Promise<void>((resolve, reject) => {
      conn.on("ready", () => {
        log(logs, "success", "SSH connection established")
        resolve()
      })
      conn.on("error", (err: Error) => {
        log(logs, "error", `SSH error: ${err.message}`)
        reject(err)
      })

      const config: any = { host, port, username, readyTimeout: 30000 }
      if (privateKey) {
        config.privateKey = privateKey
      } else {
        config.password = password
      }
      conn.connect(config)
    })

    // Helper: Execute command
    const exec = (cmd: string): Promise<{ stdout: string; stderr: string; code: number }> => {
      return new Promise((resolve, reject) => {
        conn.exec(cmd, (err: Error | undefined, stream: any) => {
          if (err) return reject(err)
          let stdout = "",
            stderr = ""
          stream.on("close", (code: number) => resolve({ stdout, stderr, code }))
          stream.on("data", (d: Buffer) => {
            stdout += d.toString()
          })
          stream.stderr.on("data", (d: Buffer) => {
            stderr += d.toString()
          })
        })
      })
    }

    // Helper: Upload content
    const upload = (content: string, remotePath: string): Promise<void> => {
      return new Promise((resolve, reject) => {
        conn.sftp((err: Error | undefined, sftp: any) => {
          if (err) return reject(err)
          const ws = sftp.createWriteStream(remotePath)
          ws.on("close", () => resolve())
          ws.on("error", reject)
          ws.end(content)
        })
      })
    }

    // Step 1: Create directories
    log(logs, "info", "Creating remote directories...")
    await exec(
      `mkdir -p /root/avalanche-market/app/static /root/avalanche-market/app/templates/auth /root/avalanche-market/scripts`,
    )
    log(logs, "success", "Directories created")

    // Step 2: Upload core files
    log(logs, "info", "Uploading Python application and config files...")
    for (const file of DEPLOY_FILES) {
      try {
        const content = await readFile(join(process.cwd(), file.local), "utf8")
        await upload(content, file.remote)
        log(logs, "info", `Uploaded: ${file.local}`)
      } catch (e: any) {
        log(logs, "warn", `Failed to upload ${file.local}: ${e.message}`)
      }
    }

    // Step 3: Upload all templates
    log(logs, "info", "Uploading Jinja2 templates...")
    for (const tpl of TEMPLATE_FILES) {
      try {
        const content = await readFile(join(process.cwd(), `scripts/app/templates/${tpl}`), "utf8")
        await upload(content, `/root/avalanche-market/app/templates/${tpl}`)
        log(logs, "info", `Template: ${tpl}`)
      } catch (e: any) {
        log(logs, "warn", `Template ${tpl}: ${e.message}`)
      }
    }

    // Step 4: Make deploy script executable
    log(logs, "info", "Setting permissions...")
    await exec("chmod +x /root/avalanche-market/deploy.sh")
    log(logs, "success", "Permissions set")

    // Step 5: Run deployment script
    log(logs, "info", "Executing deployment script (this may take several minutes)...")
    const deployResult = await exec("cd /root/avalanche-market && ./deploy.sh -v 2>&1 | tail -200")

    if (deployResult.stdout) {
      log(logs, "info", "Deploy output (last 200 lines):")
      deployResult.stdout
        .split("\n")
        .slice(-50)
        .forEach((line) => {
          if (line.trim()) log(logs, "info", line)
        })
    }

    if (deployResult.code === 0) {
      log(logs, "success", "Deployment script completed successfully")
    } else {
      log(logs, "warn", `Deployment script exited with code ${deployResult.code}`)
    }

    // Step 6: Check services
    log(logs, "info", "Checking service status...")
    const status = await exec("systemctl is-active architect-vault nginx postgresql redis tor 2>/dev/null || true")
    log(logs, "info", `Services: ${status.stdout.trim().replace(/\n/g, ", ")}`)

    // Step 7: Get onion address
    log(logs, "info", "Retrieving .onion address...")
    const onion = await exec("cat /var/lib/tor/architect/hostname 2>/dev/null || echo 'pending'")
    const onionAddress = onion.stdout.trim()
    log(logs, "success", `Onion: ${onionAddress}`)

    conn.end()
    log(logs, "success", "Deployment complete! Connection closed.")

    return NextResponse.json({
      success: true,
      message: "Deployment completed",
      onionAddress,
      logs,
    })
  } catch (error: any) {
    log(logs, "error", `Deployment failed: ${error.message}`)
    if (conn) conn.end()
    return NextResponse.json({ success: false, error: error.message, logs }, { status: 500 })
  }
}
