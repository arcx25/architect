import { AppLayout } from "@/components/app-layout"
import Link from "next/link"

const stats = [
  { label: "Wallet Balance", value: "2.458 XMR", change: "+0.12 XMR", positive: true },
  { label: "Active Orders", value: "3", change: "2 shipping", positive: true },
  { label: "Messages", value: "7", change: "3 unread", positive: false },
  { label: "Saved Items", value: "12", change: null, positive: true },
]

const recentOrders = [
  { id: "ORD-7821", item: "Digital Security Suite", status: "Delivered", date: "Dec 15" },
  { id: "ORD-7819", item: "VPN Subscription (1yr)", status: "Shipping", date: "Dec 14" },
  { id: "ORD-7815", item: "Privacy Hardware Kit", status: "Processing", date: "Dec 12" },
]

export default function DashboardPage() {
  return (
    <AppLayout username="shadow_trader" tier="buyer">
      <div className="page-header">
        <h1 className="page-title">Dashboard</h1>
        <p className="page-subtitle">Welcome back, shadow_trader</p>
      </div>

      <div className="stats-grid">
        {stats.map((stat) => (
          <div key={stat.label} className="stat-card">
            <div className="stat-label">{stat.label}</div>
            <div className="stat-value">{stat.value}</div>
            {stat.change && (
              <div className={`stat-change ${stat.positive ? "positive" : "negative"}`}>{stat.change}</div>
            )}
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="glass-card">
          <h2 className="text-xl font-semibold mb-6">Recent Orders</h2>
          <table className="data-table">
            <thead>
              <tr>
                <th>Order ID</th>
                <th>Item</th>
                <th>Status</th>
                <th>Date</th>
              </tr>
            </thead>
            <tbody>
              {recentOrders.map((order) => (
                <tr key={order.id}>
                  <td className="font-mono text-[var(--accent-cyan)]">{order.id}</td>
                  <td>{order.item}</td>
                  <td>
                    <span
                      className={`status-indicator inline-flex ${
                        order.status === "Delivered" ? "success" : order.status === "Shipping" ? "pending" : ""
                      }`}
                    >
                      <span className="status-dot" />
                      {order.status}
                    </span>
                  </td>
                  <td className="text-[var(--text-muted)]">{order.date}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <Link href="/orders" className="btn-secondary mt-4 inline-block">
            View All Orders
          </Link>
        </div>

        <div className="glass-card">
          <h2 className="text-xl font-semibold mb-6">Quick Actions</h2>
          <div className="flex flex-col gap-4">
            <Link href="/marketplace" className="btn-primary btn-glow">
              Browse Marketplace
            </Link>
            <Link href="/wallet" className="btn-secondary">
              Deposit XMR
            </Link>
            <Link href="/vendor/upgrade" className="btn-secondary">
              Upgrade to Vendor
            </Link>
          </div>

          <div className="mt-8 pt-6 border-t border-[var(--glass-border)]">
            <h3 className="text-sm font-medium text-[var(--text-muted)] mb-4">Security Status</h3>
            <div className="flex flex-col gap-3">
              <div className="flex items-center justify-between">
                <span className="text-[var(--text-secondary)]">PGP Key</span>
                <span className="text-[var(--success)]">Active</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[var(--text-secondary)]">2FA (PGP)</span>
                <span className="text-[var(--success)]">Enabled</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[var(--text-secondary)]">Session</span>
                <span className="text-[var(--warning)]">28:45 remaining</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </AppLayout>
  )
}
