import { AppLayout } from "@/components/app-layout"
import Link from "next/link"

const categories = ["All", "Digital", "Security", "Privacy", "Software", "Services"]

const products = [
  {
    id: 1,
    title: "Premium VPN Lifetime Access",
    category: "Privacy",
    vendor: "CryptoVault",
    price: "0.045 XMR",
    priceUsd: "$8.50",
    rating: 4.9,
    reviews: 234,
    image: "/vpn-security-shield-dark.jpg",
  },
  {
    id: 2,
    title: "Advanced Security Toolkit Pro",
    category: "Security",
    vendor: "ShadowDev",
    price: "0.12 XMR",
    priceUsd: "$22.80",
    rating: 4.8,
    reviews: 156,
    image: "/cybersecurity-toolkit-dark.jpg",
  },
  {
    id: 3,
    title: "Anonymous Email Service (1yr)",
    category: "Privacy",
    vendor: "DarkMail",
    price: "0.08 XMR",
    priceUsd: "$15.20",
    rating: 4.7,
    reviews: 89,
    image: "/encrypted-email-dark-theme.jpg",
  },
  {
    id: 4,
    title: "OPSEC Training Course",
    category: "Services",
    vendor: "GhostAcademy",
    price: "0.25 XMR",
    priceUsd: "$47.50",
    rating: 5.0,
    reviews: 67,
    image: "/security-training-course-dark.jpg",
  },
  {
    id: 5,
    title: "Cryptocurrency Mixer Credits",
    category: "Digital",
    vendor: "CleanCoin",
    price: "0.15 XMR",
    priceUsd: "$28.50",
    rating: 4.6,
    reviews: 312,
    image: "/cryptocurrency-mixer-dark.jpg",
  },
  {
    id: 6,
    title: "Privacy-Focused OS Image",
    category: "Software",
    vendor: "LinuxGhost",
    price: "0.02 XMR",
    priceUsd: "$3.80",
    rating: 4.9,
    reviews: 445,
    image: "/linux-operating-system-dark.jpg",
  },
]

export default function MarketplacePage() {
  return (
    <AppLayout username="shadow_trader" tier="buyer">
      <div className="page-header">
        <h1 className="page-title">Marketplace</h1>
        <p className="page-subtitle">Browse verified vendors and products</p>
      </div>

      <div className="search-container">
        <svg className="search-icon" viewBox="0 0 24 24" fill="currentColor">
          <path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z" />
        </svg>
        <input type="search" placeholder="Search products, vendors, categories..." className="search-input" />
      </div>

      <div className="categories-filter">
        {categories.map((cat, i) => (
          <button key={cat} className={`category-pill ${i === 0 ? "active" : ""}`}>
            {cat}
          </button>
        ))}
      </div>

      <div className="products-grid">
        {products.map((product) => (
          <Link key={product.id} href={`/marketplace/${product.id}`} className="product-card">
            <img src={product.image || "/placeholder.svg"} alt={product.title} className="product-image" />
            <div className="product-content">
              <div className="product-category">{product.category}</div>
              <h3 className="product-title">{product.title}</h3>
              <div className="product-vendor">
                by <span className="text-[var(--accent-cyan)]">{product.vendor}</span>
              </div>
              <div className="product-footer">
                <div>
                  <div className="product-price">{product.price}</div>
                  <div className="product-price-usd">{product.priceUsd}</div>
                </div>
                <div className="product-rating">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
                  </svg>
                  {product.rating} ({product.reviews})
                </div>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </AppLayout>
  )
}
