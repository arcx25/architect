import { AppLayout } from "@/components/app-layout"

export default function SettingsPage() {
  return (
    <AppLayout username="shadow_trader" tier="buyer">
      <div className="page-header">
        <h1 className="page-title">Settings</h1>
        <p className="page-subtitle">Manage your account</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="glass-card">
          <h2 className="text-xl font-semibold mb-6">PGP Key</h2>
          <div className="form-group">
            <label>Current Public Key Fingerprint</label>
            <div className="glass-card-dark p-4">
              <code className="text-[var(--accent-cyan)] text-sm font-mono">
                A7F2 C9D1 E3B4 5678 9ABC DEF0 1234 5678 90AB CDEF
              </code>
            </div>
          </div>
          <div className="form-group">
            <label>Update PGP Public Key</label>
            <textarea rows={8} placeholder="Paste new PGP public key..." className="glass-input mono" />
            <small className="form-hint">You will need to verify the new key before it becomes active.</small>
          </div>
          <button className="btn-secondary">Update Key</button>
        </div>

        <div className="glass-card">
          <h2 className="text-xl font-semibold mb-6">Security</h2>

          <div className="space-y-4">
            <div className="flex justify-between items-center py-3 border-b border-[var(--glass-border)]">
              <div>
                <div className="font-medium">PGP Authentication</div>
                <div className="text-sm text-[var(--text-muted)]">Required for all logins</div>
              </div>
              <span className="text-[var(--success)]">Active</span>
            </div>

            <div className="flex justify-between items-center py-3 border-b border-[var(--glass-border)]">
              <div>
                <div className="font-medium">Session Timeout</div>
                <div className="text-sm text-[var(--text-muted)]">Auto-logout after inactivity</div>
              </div>
              <select className="glass-input w-auto">
                <option>15 minutes</option>
                <option selected>30 minutes</option>
                <option>1 hour</option>
              </select>
            </div>

            <div className="flex justify-between items-center py-3 border-b border-[var(--glass-border)]">
              <div>
                <div className="font-medium">Login Notifications</div>
                <div className="text-sm text-[var(--text-muted)]">PGP-encrypted alerts for new sessions</div>
              </div>
              <button className="btn-secondary text-sm">Enable</button>
            </div>
          </div>
        </div>

        <div className="glass-card">
          <h2 className="text-xl font-semibold mb-6">Active Sessions</h2>
          <div className="space-y-4">
            <div className="flex justify-between items-center py-3 border-b border-[var(--glass-border)]">
              <div>
                <div className="font-medium">Current Session</div>
                <div className="text-sm text-[var(--text-muted)]">Tor Circuit • Started 25 min ago</div>
              </div>
              <span className="text-[var(--success)] text-sm">Active</span>
            </div>
          </div>
          <button className="btn-secondary mt-4 text-[var(--error)]">Terminate All Other Sessions</button>
        </div>

        <div className="glass-card">
          <h2 className="text-xl font-semibold mb-6">Danger Zone</h2>
          <div className="space-y-4">
            <div className="p-4 border border-[var(--error)] rounded-lg bg-[rgba(255,0,85,0.05)]">
              <div className="font-medium text-[var(--error)] mb-2">Delete Account</div>
              <p className="text-sm text-[var(--text-muted)] mb-4">
                This will permanently delete your account and all associated data. This action cannot be undone.
              </p>
              <button className="btn-secondary text-[var(--error)] border-[var(--error)]">Delete Account</button>
            </div>
          </div>
        </div>
      </div>
    </AppLayout>
  )
}
