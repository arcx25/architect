import { AppLayout } from "@/components/app-layout"
import Link from "next/link"

const orders = [
  {
    id: "ORD-7821",
    item: "Digital Security Suite",
    vendor: "ShadowDev",
    price: "0.12 XMR",
    status: "delivered",
    date: "Dec 15, 2024",
  },
  {
    id: "ORD-7819",
    item: "VPN Subscription (1yr)",
    vendor: "CryptoVault",
    price: "0.045 XMR",
    status: "shipping",
    date: "Dec 14, 2024",
  },
  {
    id: "ORD-7815",
    item: "Privacy Hardware Kit",
    vendor: "GhostHW",
    price: "0.85 XMR",
    status: "processing",
    date: "Dec 12, 2024",
  },
  {
    id: "ORD-7810",
    item: "OPSEC Training Course",
    vendor: "GhostAcademy",
    price: "0.25 XMR",
    status: "delivered",
    date: "Dec 8, 2024",
  },
]

const statusColors: Record<string, string> = {
  delivered: "success",
  shipping: "pending",
  processing: "",
  disputed: "error",
}

export default function OrdersPage() {
  return (
    <AppLayout username="shadow_trader" tier="buyer">
      <div className="page-header">
        <h1 className="page-title">Orders</h1>
        <p className="page-subtitle">Track your purchases</p>
      </div>

      <div className="glass-card">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-semibold">Order History</h2>
          <div className="flex gap-3">
            <button className="category-pill active">All</button>
            <button className="category-pill">Active</button>
            <button className="category-pill">Completed</button>
          </div>
        </div>

        <table className="data-table">
          <thead>
            <tr>
              <th>Order ID</th>
              <th>Item</th>
              <th>Vendor</th>
              <th>Price</th>
              <th>Status</th>
              <th>Date</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {orders.map((order) => (
              <tr key={order.id}>
                <td className="font-mono text-[var(--accent-cyan)]">{order.id}</td>
                <td>{order.item}</td>
                <td className="text-[var(--text-muted)]">{order.vendor}</td>
                <td>{order.price}</td>
                <td>
                  <span className={`status-indicator ${statusColors[order.status]} inline-flex`}>
                    <span className="status-dot" />
                    <span className="capitalize">{order.status}</span>
                  </span>
                </td>
                <td className="text-[var(--text-muted)]">{order.date}</td>
                <td>
                  <Link href={`/orders/${order.id}`} className="text-[var(--neon-pink)] hover:underline text-sm">
                    View
                  </Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </AppLayout>
  )
}
