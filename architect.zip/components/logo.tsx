export function Logo({ size = "default" }: { size?: "small" | "default" | "large" }) {
  const sizes = {
    small: { box: "w-8 h-8 text-lg", text: "text-sm" },
    default: { box: "w-12 h-12 text-2xl", text: "text-xl" },
    large: { box: "w-16 h-16 text-3xl", text: "text-2xl" },
  }

  return (
    <div className="logo">
      <div className={`logo-box ${sizes[size].box}`}>A</div>
      <span className={`logo-text ${sizes[size].text}`}>ARCHITECT</span>
    </div>
  )
}
