import type React from "react"
import { Navigation } from "./navigation"

interface AppLayoutProps {
  children: React.ReactNode
  username?: string
  tier?: string
}

export function AppLayout({ children, username, tier }: AppLayoutProps) {
  return (
    <div className="app-layout">
      <Navigation username={username} tier={tier} />
      <main className="main-content">{children}</main>
    </div>
  )
}
