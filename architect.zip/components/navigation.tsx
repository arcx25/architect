"use client"

import type React from "react"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Logo } from "./logo"

const navItems = [
  { href: "/dashboard", label: "Dashboard", icon: "dashboard" },
  { href: "/marketplace", label: "Marketplace", icon: "marketplace" },
  { href: "/orders", label: "Orders", icon: "orders" },
  { href: "/messages", label: "Messages", icon: "messages", badge: 3 },
  { href: "/wallet", label: "Wallet", icon: "wallet" },
]

const bottomItems = [{ href: "/settings", label: "Settings", icon: "settings" }]

const icons: Record<string, React.ReactNode> = {
  dashboard: (
    <svg className="nav-icon" viewBox="0 0 24 24">
      <path d="M3 13h8V3H3v10zm0 8h8v-6H3v6zm10 0h8V11h-8v10zm0-18v6h8V3h-8z" />
    </svg>
  ),
  marketplace: (
    <svg className="nav-icon" viewBox="0 0 24 24">
      <path d="M7 18c-1.1 0-1.99.9-1.99 2S5.9 22 7 22s2-.9 2-2-.9-2-2-2zM1 2v2h2l3.6 7.59-1.35 2.45c-.16.28-.25.61-.25.96 0 1.1.9 2 2 2h12v-2H7.42c-.14 0-.25-.11-.25-.25l.03-.12.9-1.63h7.45c.75 0 1.41-.41 1.75-1.03l3.58-6.49c.08-.14.12-.31.12-.48 0-.55-.45-1-1-1H5.21l-.94-2H1zm16 16c-1.1 0-1.99.9-1.99 2s.89 2 1.99 2 2-.9 2-2-.9-2-2-2z" />
    </svg>
  ),
  orders: (
    <svg className="nav-icon" viewBox="0 0 24 24">
      <path d="M19 3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.11 0 2-.9 2-2V5c0-1.1-.89-2-2-2zm-9 14l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z" />
    </svg>
  ),
  messages: (
    <svg className="nav-icon" viewBox="0 0 24 24">
      <path d="M20 2H4c-1.1 0-1.99.9-1.99 2L2 22l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zM6 9h12v2H6V9zm8 5H6v-2h8v2zm4-6H6V6h12v2z" />
    </svg>
  ),
  wallet: (
    <svg className="nav-icon" viewBox="0 0 24 24">
      <path d="M21 18v1c0 1.1-.9 2-2 2H5c-1.11 0-2-.9-2-2V5c0-1.1.89-2 2-2h14c1.1 0 2 .9 2 2v1h-9c-1.11 0-2 .9-2 2v8c0 1.1.89 2 2 2h9zm-9-2h10V8H12v8zm4-2.5c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5z" />
    </svg>
  ),
  settings: (
    <svg className="nav-icon" viewBox="0 0 24 24">
      <path d="M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.09.63-.09.94s.02.64.07.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z" />
    </svg>
  ),
}

interface NavigationProps {
  username?: string
  tier?: string
}

export function Navigation({ username = "anon_user", tier = "buyer" }: NavigationProps) {
  const pathname = usePathname()

  return (
    <nav className="left-nav">
      <div className="nav-header">
        <Logo />
      </div>

      <ul className="nav-menu">
        {navItems.map((item) => (
          <li key={item.href}>
            <Link href={item.href} className={`nav-item ${pathname === item.href ? "active" : ""}`}>
              {icons[item.icon]}
              <span>{item.label}</span>
              {item.badge && <span className="badge">{item.badge}</span>}
            </Link>
          </li>
        ))}

        <li className="nav-divider" />

        {bottomItems.map((item) => (
          <li key={item.href}>
            <Link href={item.href} className={`nav-item ${pathname === item.href ? "active" : ""}`}>
              {icons[item.icon]}
              <span>{item.label}</span>
            </Link>
          </li>
        ))}
      </ul>

      <div className="nav-footer">
        <div className="user-profile">
          <div className="user-avatar">{username[0].toUpperCase()}</div>
          <div className="user-info">
            <div className="user-name">{username}</div>
            <div className="user-tier">{tier}</div>
          </div>
        </div>
      </div>
    </nav>
  )
}
